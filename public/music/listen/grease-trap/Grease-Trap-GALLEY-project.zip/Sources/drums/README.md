# Grease Trap — drum source phrases

Nine original four-bar phrases, all at 106 BPM. SIZZLE supplies the 49 Hz grease-pump kick and the relay/timer hats; CLATTER supplies the dry griddle-slap snare, ceramic mechanism, and hollow drain-knock fill. The rhythm has heavy downbeats, sly displaced sixteenth-note kicks, quieter pickup notes, and a restrained backbeat. The reference is the broad industrial-funk feel, not a transcription of an existing song.

| GALLEY track | Verse | Chorus | Transition/fill |
| --- | --- | --- | --- |
| Warm kick | `kick-verse.wav` | `kick-chorus.wav` | `kick-fill.wav` |
| Snare/mechanism | `snare-verse.wav` | `snare-chorus.wav` | `snare-fill.wav` |
| Relay hats | `hats-verse.wav` | `hats-chorus.wav` | `hats-fill.wav` |

All are stereo 48 kHz, 16-bit PCM WAVs with exactly 434,717 frames. This is the nearest sample-frame representation of sixteen beats at 106 BPM (9.056604 seconds). No silence or decay tail is appended. Use `beatLength: 16` when arranging instead of deriving beats from rounded WAV duration.

Velocity varies per hit. Hats and mechanical ticks typically lean 2–11 ms behind the grid; backbeats are 8 ms late. Some kick pickups lean 3–4 ms ahead. These offsets are explicit in the portable pattern JSON, rather than introduced by randomized playback timing. Fill variants become busier in the final bar only.

Rendering loads the current production standalone HTML into Chromium and calls its unchanged native audio engine with the authored events. Two cycles render through the full native instrument/master chain. The second cycle is extracted to retain settled compressor behavior and crossing phrase tails. Only negligible DC removal, a gain reduction if needed, PCM encoding, and 8-/24-frame boundary fades occur after native rendering. No recordings, external samples, alternative oscillator renderer, or app-code edits were used.

Each `.json` file is a reopenable source-instrument snapshot; each `.pattern.json` is the corresponding full four-bar portable note pattern. `manifest.json` records duration, frame count, measured peak/RMS, voice origin, source snapshots, note counts, and raw peak before export. All exports are finite, non-silent, and below 0.9 peak. Hats are intentionally short and dark; a modest mixer lift can emphasize the small relay details without making them harsh.

To reproduce: `node /workspace/grease-trap/drums/render.cjs` (requires the existing Chromium and song helpers). The renderer modifies only this source directory.
