/* BOWER: portable scores for a small, unreasonable string garden. */
(() => {
  'use strict';
  const VERSION='1.0.0';
  const SCALES={minor:[0,2,3,5,7,8,10],major:[0,2,4,5,7,9,11],dorian:[0,2,3,5,7,9,10],pentatonic:[0,2,4,7,9],lydian:[0,2,4,6,7,9,11],whole:[0,2,4,6,8,10]};
  const DIVISIONS={'1/16':.25,'1/8':.5,'1/4':1,'3/8':1.5,'1/2':2};
  const BODIES=['wood','steel','glass','hollow'];
  const EXCITERS=['finger','pick','hammer','wire'];
  const copy=v=>JSON.parse(JSON.stringify(v));
  const n=(v,a,b,d)=>typeof v==='number'&&Number.isFinite(v)?Math.max(a,Math.min(b,v)):d;
  const int=(v,a,b,d)=>Math.round(n(v,a,b,d));
  const pick=(v,list,d)=>list.includes(v)?v:d;
  const text=(v,d)=>typeof v==='string'?v.replace(/[\u0000-\u001f\u007f]/g,'').trim().slice(0,90)||d:d;
  const bool=(v,d=false)=>typeof v==='boolean'?v:d;
  const step=(on=false,degree=0,velocity=.7,probability=1)=>({on,degree,velocity,probability});
  function lane(i){const degrees=[[0,4,7,2],[0,2,4,6,7],[7,9,11,12],[0,7,4,2]][i];return{name:['Root & rumour','The crooked trellis','A branch of perhaps','Leaves after midnight'][i],length:[16,12,7,16][i],division:['1/8','1/8','1/4','1/16'][i],direction:'forward',octave:[-1,0,1,0][i],level:[.72,.54,.42,.28][i],pan:[-.18,-.52,.48,.15][i],mute:false,solo:false,decay:[3.5,2.2,4.5,.8][i],brightness:[.5,.65,.72,.35][i],position:[.22,.37,.18,.43][i],tension:0,dispersion:[.04,.12,.18,.03][i],body:BODIES[i],exciter:EXCITERS[i],evolve:0,steps:Array.from({length:16},(_,j)=>step(j%[4,3,2,5][i]===0,degrees[j%degrees.length],j===0?.92:.65,1))};}
  function defaultState(){return{version:VERSION,name:'The branches are practising backwards',tempo:104,root:48,scale:'dorian',swing:.12,humanize:.008,seed:72819,evolution:false,lanes:Array.from({length:4},(_,i)=>lane(i)),master:{volume:.72,width:.9,echo:.24,division:'3/8',feedback:.38,room:.25},exportBars:4};}
  function normalizePlain(raw={}){const d=defaultState();const m=raw.master||{};return{version:VERSION,name:text(raw.name,d.name),tempo:n(raw.tempo,40,190,d.tempo),root:int(raw.root,36,72,d.root),scale:pick(raw.scale,Object.keys(SCALES),d.scale),swing:n(raw.swing,0,.6,d.swing),humanize:n(raw.humanize,0,.045,d.humanize),seed:int(raw.seed,1,0xffffffff,d.seed),evolution:bool(raw.evolution),exportBars:int(raw.exportBars,1,16,4),master:{volume:n(m.volume,0,1,d.master.volume),width:n(m.width,0,1,d.master.width),echo:n(m.echo,0,1,d.master.echo),division:pick(m.division,Object.keys(DIVISIONS),d.master.division),feedback:n(m.feedback,0,.8,d.master.feedback),room:n(m.room,0,1,d.master.room)},lanes:Array.from({length:4},(_,i)=>{const l=raw.lanes?.[i]||{},a=d.lanes[i];return{name:text(l.name,a.name),length:int(l.length,1,16,a.length),division:pick(l.division,Object.keys(DIVISIONS),a.division),direction:pick(l.direction,['forward','reverse','pendulum','random'],a.direction),octave:int(l.octave,-2,2,a.octave),level:n(l.level,0,1,a.level),pan:n(l.pan,-1,1,a.pan),mute:bool(l.mute),solo:bool(l.solo),decay:n(l.decay,.15,12,a.decay),brightness:n(l.brightness,0,1,a.brightness),position:n(l.position,.03,.49,a.position),tension:n(l.tension,-40,40,0),dispersion:n(l.dispersion,0,.6,a.dispersion),body:pick(l.body,BODIES,a.body),exciter:pick(l.exciter,EXCITERS,a.exciter),evolve:n(l.evolve,0,1,0),steps:Array.from({length:16},(_,j)=>{const s=l.steps?.[j]||a.steps[j];return{on:bool(s.on,a.steps[j].on),degree:int(s.degree,-7,21,a.steps[j].degree),velocity:n(s.velocity,.05,1,a.steps[j].velocity),probability:n(s.probability,0,1,1)};})};})};}
  function degreeMidi(state,index,degree){const sc=SCALES[state.scale]||SCALES.minor,d=Math.round(degree),oct=Math.floor(d/sc.length),at=((d%sc.length)+sc.length)%sc.length;return Math.max(24,Math.min(100,state.root+state.lanes[index].octave*12+oct*12+sc[at]));}
  function noteName(note){return['C','C♯','D','E♭','E','F','F♯','G','A♭','A','B♭','B'][((note%12)+12)%12]+(Math.floor(note/12)-1);}
  function serialize(state){return JSON.stringify({format:'bower-project',formatVersion:1,appVersion:VERSION,state:normalize(state)},null,2);}
  function parseProject(value){if(typeof value!=='string'||value.length>1024*1024)throw new Error('Choose a BOWER project smaller than 1 MB.');let p;try{p=JSON.parse(value);}catch{throw new Error('This file is not valid JSON.');}if(p?.format!=='bower-project'||p.formatVersion!==1||!p.state||!Array.isArray(p.state.lanes)||p.state.lanes.length!==4||p.state.lanes.some(l=>!l||!Array.isArray(l.steps)||l.steps.length!==16)||!p.state.master)throw new Error('This is not a complete BOWER project.');const valid=(value,example)=>{if(Array.isArray(example))return Array.isArray(value)&&value.length===example.length&&example.every((x,i)=>valid(value[i],x));if(example&&typeof example==='object')return value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(example).every(k=>valid(value[k],example[k]));if(typeof example==='number')return typeof value==='number'&&Number.isFinite(value);return typeof value===typeof example;};if(!valid(p.state,defaultState()))throw new Error('The BOWER score contains missing or invalid controls.');return normalize(p.state);}
  function euclidean(length,pulses,rotation=0){length=Math.max(1,Math.min(16,length|0));pulses=Math.max(0,Math.min(length,pulses|0));return Array.from({length:16},(_,i)=>i<length&&(((i-rotation+length)%length)*pulses)%length<pulses);}

  // Exact imported notes travel with the native patch, without flattening chords or timing.
  function normalize(raw) {
    const state = normalizePlain(raw);
    if (raw && raw.musicLabPattern !== undefined) {
      const overlay = raw.musicLabPattern, schema = window.MusicLabPatternSchema;
      if (!schema) throw new Error('The portable note-pattern validator is unavailable.');
      if (!overlay || Object.prototype.toString.call(overlay) !== '[object Object]' || !overlay.voiceMap || Object.prototype.toString.call(overlay.voiceMap) !== '[object Object]') throw new Error('The imported note pattern is incomplete.');
      const pattern = schema.parse(overlay.pattern), targets = new Set(Array.from({length:4},(_,i)=>String(i))), voiceMap = {};
      for (const voice of pattern.voices) {
        const target = overlay.voiceMap[voice.id];
        if (!Object.prototype.hasOwnProperty.call(overlay.voiceMap, voice.id) || typeof target !== 'string' || !targets.has(target)) throw new Error('The imported pattern refers to an unavailable instrument voice.');
        voiceMap[voice.id] = target;
      }
      if (Object.keys(overlay.voiceMap).some(id => !pattern.voices.some(voice => voice.id === id))) throw new Error('The imported voice map contains an unknown source voice.');
      state.musicLabPattern = { pattern, voiceMap };
    }
    return state;
  }
  window.BowerSchema={VERSION,SCALES,DIVISIONS,BODIES,EXCITERS,copy,step,defaultState,normalize,degreeMidi,noteName,serialize,parseProject,euclidean};
})();
