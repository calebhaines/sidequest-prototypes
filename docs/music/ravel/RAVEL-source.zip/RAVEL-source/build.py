"""Build RAVEL's standalone HTML and reproducible editable source download."""
from pathlib import Path
import base64
import argparse
import runpy
import zipfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output', type=Path, help='Build an isolated standalone preview.')
parser.add_argument('--archive', type=Path, help='Optional editable source ZIP destination.')
args = parser.parse_args()
root = Path(__file__).resolve().parent
exchange_dir = root / 'shared' if (root / 'shared' / 'bundle_audio_exchange.py').exists() else root.parent / 'shared'
exchange_helpers = runpy.run_path(str(exchange_dir / 'bundle_audio_exchange.py'))
faces = []
for family, weight, style, file in [
    ('Ravel Sans', 400, 'normal', 'noto-sans-regular.woff2'),
    ('Ravel Sans', 700, 'normal', 'noto-sans-bold.woff2'),
    ('Ravel Serif', 400, 'normal', 'noto-serif-regular.woff2'),
    ('Ravel Serif', 400, 'italic', 'noto-serif-italic.woff2'),
]:
    encoded = base64.b64encode((root / 'fonts' / file).read_bytes()).decode('ascii')
    faces.append(f"@font-face{{font-family:'{family}';font-style:{style};font-weight:{weight};font-display:swap;src:url(data:font/woff2;base64,{encoded}) format('woff2')}}")
license = (root / 'fonts' / 'LICENSE.txt').read_text().replace('*/', '* /')
faces.append('/* Embedded Noto fonts: copyright Google; SIL Open Font License 1.1.\n' + license + '\n*/')
css_template = (root / 'styles.css').read_text()
if css_template.count('/* FONT_FACES */') != 1:
    raise ValueError('styles.css needs exactly one FONT_FACES slot.')
css = css_template.replace('/* FONT_FACES */', '\n'.join(faces))
scripts = '\n'.join((root / name).read_text() for name in ['schema.js', 'presets.js', 'audio-engine.js', 'app.js']).replace('</script', '<\\/script')
template = (root / 'app.html').read_text()
if any(template.count(slot) != 1 for slot in ['<!-- STYLES -->', '<!-- SCRIPTS -->']):
    raise ValueError('app.html needs exactly one STYLES and SCRIPTS slot.')
html = template.replace('<!-- STYLES -->', '<style>\n' + css + '\n</style>').replace('<!-- SCRIPTS -->', '<script>\n' + scripts + '\n</script>')
html = '\n'.join(line.rstrip() for line in html.splitlines()) + '\n'
html = exchange_helpers['embed_exchange'](html, 'ravel', root)
target = args.output or root / 'index.html'
target.parent.mkdir(parents=True, exist_ok=True)
target.write_text(html)
print(f'Built RAVEL: {len(html.encode()):,} bytes, all assets embedded.')

if args.archive is not None or args.output is None and (root.parent / 'music' / 'README.md').exists():
    archive = args.archive or root.parent / 'music' / 'ravel' / 'RAVEL-source.zip'
    archive.parent.mkdir(parents=True, exist_ok=True)
    files = [root / name for name in ['app.html', 'styles.css', 'schema.js', 'presets.js', 'audio-engine.js', 'app.js', 'build.py', 'README.md']]
    files += sorted(root.glob('*checks.cjs'))
    files += sorted((root / 'fonts').glob('*'))
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in files:
            info = zipfile.ZipInfo('RAVEL-source/' + str(path.relative_to(root)), (2026, 10, 5, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, path.read_bytes())
        for name, data in exchange_helpers['exchange_sources'](root):
            info = zipfile.ZipInfo('RAVEL-source/' + name, (2026, 10, 5, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, data)
    print(f'Packaged RAVEL source: {archive.stat().st_size:,} bytes.')
