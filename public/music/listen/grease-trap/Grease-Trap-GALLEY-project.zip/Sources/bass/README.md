# Grease Trap: bass and pilot-light hook

Eight newly authored ingredients for a 106 BPM, D minor industrial funk composition. Every sound was exported through the current Kitchen browser instrument, with no external synthesizer or sample replacement. The note sequences are original.

All WAVs are stereo 16-bit PCM at 48 kHz, 434,717 frames, exactly one 16-beat/four-bar phrase with no appended tail. `manifest.json` contains duration, level, source artifact hash, note-pattern and project-snapshot paths. Project snapshots were serialized and parsed successfully by the corresponding native schema. The reusable `.pattern.json` files retain note pitch, beat, duration, velocity and voice mapping.

## Bass track: ROUX

ROUX combines a muted pulse oscillator, sine foundation and a small amount of copper waveguide body. The filter envelope provides bite without turning every note into an acid squeal. Native portamento is 75 ms, enabled only when consecutive authored gates overlap; most notes have space around them. Internal echo is off and the source is mono-compatible.

The verse's central shape is D2 — D2/F2 — D2 — D2 — C2/D2, with a deliberately irregular 0, 1.25, 1.75, 2.125, 2.5, 3.5, 3.75 beat grid. That small early note inside the middle beat group creates an uneasy skip. Second and fourth bars substitute E-flat pickups; later variants add octave D3 answers or quick A-flat tension. This is an authored bass phrase rather than a recreation of an existing riff.

- `bass-intro.wav`: sparse, dark pulse; suitable before the full groove or during the outro.
- `bass-verse.wav`: main syncopated hook, repeated with small four-bar changes.
- `bass-chorus.wav`: slightly brighter and stronger with octave responses.
- `bass-bridge.wav`: longer half-time notes, occasional A-flat, and quieter filter motion.
- `bass-final.wav`: chorus with two new descending turnaround fills.

Bass source peaks are approximately 0.43–0.45 and RMS 0.085–0.134. Low-frequency energy below 20 Hz stays below 0.34% in the spectral audit; the lowest authored note is C2. A modest GALLEY high-pass around 30 Hz and restrained BROILER saturation can seat this against the kick without discarding its rounded foundation.

## Hook track: LEAVEN

Muted DCO pulse with a quick envelope, restrained chorus and no internal echo or reverb. This provides the original melodic identifier above the bass without filling all the spaces between drum hits. The final phrase uses the native sync oscillator for more teeth.

- `hook-call.wav`: D4/F4/A4/G4, followed by D4/F4/A-flat4/F4; two additional bars turn toward C4 and E-flat4.
- `hook-response.wav`: a lower, sparser F4/D4/A3 reply, leaving room for the rhythm.
- `hook-final.wav`: a brighter version of the call with soft off-grid sixteenth replies.

These intentionally restrained source WAVs peak at 0.116–0.158, with RMS 0.015–0.025. Give the hook approximately 8–11 dB of source gain relative to its raw render, or use an equivalent GALLEY effect gain, then balance by ear. A high-pass around 150–200 Hz keeps it away from the bass; a small clocked GALLEY delay can make the call float without softening the dry rhythmic attack. If the final sync sound needs taming, a gentle upper-mid cut is sufficient.

`audio-audit.json` records peak, RMS, DC, spectral energy fractions and end-of-file values. All WAVs contain finite, nonzero audio with comfortable headroom, and all last samples are zero. `playback-audit.json` additionally verifies actual browser playback, audible native-engine meters, project reload, retained note patterns and stopping for both instruments. The per-phrase native projects remain playable and editable in ROUX or LEAVEN.
