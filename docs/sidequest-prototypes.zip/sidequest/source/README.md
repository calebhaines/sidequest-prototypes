# Sidequest

Six original, playable pixel RPG concepts in one browser gallery:

- **Moss & Myth** — woodland fantasy, forgotten magic and forest folk.
- **Neon Afterglow** — cyberpunk city, street conspiracies and faction choices.
- **The Dustlands** — desert frontier, salvage and a settlement running out of water.
- **Borrowed Sky** — surreal suburb, everyday magic and a town frozen in time.
- **Velvet Static** — a Lynch-inspired original mystery in Mercy Falls, with six eccentric witnesses, waking and dream realities, camera-flash defenses, clues, and three endings.
- **Hidden Ember** — a Naruto-inspired original shinobi adventure, with hidden villages, chakra, three active jutsus, clan loyalties, and a combat or peaceful mission route.

Each is deliberately a small prototype, with exploration, branching dialogue, a short quest, real-time combat, loot and character progression. Choose a favorite in the game sidebar to mark it in the gallery. Your selection and shortlist are saved locally in your browser.

## Run

For the quickest start, download the packaged ZIP, extract it, and open **PLAY.html** in your browser. This standalone version includes all six games, pixel art, and fonts, and works offline without a server.

The ZIP also includes the production website and complete editable source. To regenerate the downloadable ZIP and HTML from the source, run `npm run package` after installing dependencies (packaging also requires Python 3). The gallery's **Download prototypes** link serves the ZIP generated in `public/downloads/`.

```sh
npm install
npm run dev
```

Open the URL printed by Vite. Everything runs client-side; no account or backend is needed. Fonts and all artwork are bundled locally; playing does not require any external services.

```sh
npm run build
npm run preview
```

## Controls

WASD or arrow keys: move. Shift: sprint. E or Enter: interact. Space: attack. M: map. Escape: close dialogue/map or leave the prototype. Touch controls are available on small screens. Ambient sound is optional.

In **Velvet Static**, press **Q** to cross between waking and dream, and **Space** to repel threats with a camera flash. In **Hidden Ember**, press **1** for Ember Release, **2** for Shadow Clone, and **3** for Substitution; **Space** throws a kunai. Chakra replenishes over time. Abilities can also be activated using the on-screen buttons.

Open a specific prototype using `#play-lynch` or `#play-shinobi` on the gallery URL. New worlds appear first; the original four remain available.

The art and world design are original. These prototypes explore the charm of classic top-down pixel RPGs and the progression loop of open-world RPGs. They are small concept slices, not a finished huge open world.
