# Sidequest

Six original, playable pixel RPG concepts in one browser gallery:

- **Moss & Myth** — woodland fantasy, forgotten magic and forest folk.
- **Neon Afterglow** — cyberpunk city, street conspiracies and faction choices.
- **The Dustlands** — desert frontier, salvage and a settlement running out of water.
- **Borrowed Sky** — surreal suburb, everyday magic and a town frozen in time.
- **Velvet Static** — a Lynch-inspired county mystery, with fourteen witnesses, mill roads, a lakeside observatory, ferry marshes, waking and dream realities, six main clues, three side stories, and three endings.
- **Hidden Ember** — a Naruto-inspired original shinobi adventure, with fourteen characters, distant forests and clan outposts, waterfall training, lantern markets, chakra, three active jutsus, six main trials, three side missions, and three endings.

Velvet Static and Hidden Ember are the two finalists. Their maps are each 4800 × 3456 world pixels, nine times their original area. Both use pixel color and shading without outlines, branch conversations around player replies, remember dialogue decisions, and unlock travel stops through exploration. The four original prototypes retain their existing worlds and gameplay.

Each is deliberately a small prototype, with exploration, branching dialogue, a short quest, real-time combat, loot and character progression. Choose a favorite in the game sidebar to mark it in the gallery. Your selection and shortlist are saved locally in your browser.

## Run

For the quickest start, download the packaged ZIP, extract it, and open **PLAY.html** in your browser. This standalone version includes all six games, pixel art, and fonts, and works offline without a server.

The ZIP also includes the production website and complete editable source. To regenerate the downloadable ZIP and HTML from the source, run `npm run package` after installing dependencies (packaging also requires Python 3). The gallery's **Download prototypes** link serves the ZIP generated in `public/downloads/`.

```sh
npm install
npm run dev
```

Open the URL printed by Vite. Everything runs client-side; no account or backend is needed. Fonts and all artwork are bundled locally; playing does not require any external services.

```sh
npm run build
npm run preview
```

## Controls

WASD or arrow keys: move. Shift: sprint. E or Enter: interact. Space: attack. M: map. Escape: close dialogue/map or leave the prototype. Touch controls are available on small screens. Ambient sound is optional.

In **Velvet Static**, press **Q** to cross between waking and dream, and **Space** to repel threats with a camera flash. In **Hidden Ember**, press **1** for Ember Release, **2** for Shadow Clone, and **3** for Substitution; **Space** throws a kunai. Chakra replenishes over time. Abilities can also be activated using the on-screen buttons.

In both finalists, **T** opens travel to stops you have discovered. The map includes a travel button. Accept side stories through conversations, then use **Other stories** in the sidebar to follow one or return to the main story. Conversations remember your choices within the current play session. Gameplay starts fresh when you re-enter a world.

Open a specific prototype using `#play-lynch` or `#play-shinobi` on the gallery URL. The two finalists appear first; the original four remain available.

The art and world design are original. These prototypes explore the charm of classic top-down pixel RPGs and the progression loop of open-world RPGs. They are small concept slices, not a finished huge open world.
