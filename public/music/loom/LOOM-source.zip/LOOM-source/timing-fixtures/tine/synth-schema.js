/* CLATTER uses physical units throughout its voice editor and synthesis engine. */
(function () {
  'use strict';

  const isRecord = (value) => value !== null && typeof value === 'object' && !Array.isArray(value)
    && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null);
  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
  const finite = (value, min, max) => typeof value === 'number' && Number.isFinite(value) && value >= min && value <= max;
  const descriptor = (key, label, min, max, log, unit, hint) => Object.freeze({ id: key, key, label, min, max, log, unit, hint });

  const models = Object.freeze([
    Object.freeze({ id: 'string', name: 'String', description: 'A stretched string. Harmonic plucks become bright, wiry percussion as stiffness rises.', material: 'Tensioned wire', color: '#c9b597' }),
    Object.freeze({ id: 'beam', name: 'Beam', description: 'A struck bar with bending modes. Dry wooden knocks, hollow blocks, and ringing metal.', material: 'Struck bar', color: '#b5a27d' }),
    Object.freeze({ id: 'marimba', name: 'Marimba', description: 'A tuned wooden bar. Soft mallets reveal rounded fundamentals and bell-like overtones.', material: 'Tuned wood', color: '#a7b892' }),
    Object.freeze({ id: 'drumhead', name: 'Drumhead', description: 'A circular head under tension. Responsive toms, snares, and hand-drum tones.', material: 'Taut skin', color: '#c4a196' }),
    Object.freeze({ id: 'membrane', name: 'Membrane', description: 'A flexible resonating surface. Deep kicks, rubbery impacts, and bending low percussion.', material: 'Flexible surface', color: '#d0b095' }),
    Object.freeze({ id: 'plate', name: 'Plate', description: 'A dense sheet of resonant metal. Shimmering cymbals, gongs, and bright inharmonic impacts.', material: 'Metal sheet', color: '#99afb6' }),
    Object.freeze({ id: 'bell', name: 'Bell', description: 'A cast shell with a low hum, a singing prime, and distinct upper partials. Clear chimes and dense, bronze-like strikes.', material: 'Cast shell', color: '#d0b081' }),
    Object.freeze({ id: 'bowl', name: 'Bowl', description: 'A curved shell with closely paired resonances. Rounded singing tones and slowly shimmering, gong-like percussion.', material: 'Curved shell', color: '#b6accb' }),
    Object.freeze({ id: 'tube', name: 'Tube', description: 'A closed air column with odd harmonic modes. Hollow knocks, bamboo-like percussion, and woody pitched pulses.', material: 'Air column', color: '#a8bbb0' })
  ]);
  const strikeMaterials = Object.freeze([
    Object.freeze({ id: 'neutral', name: 'Neutral', description: 'The original shaped contact pulse. Hardness and contact time define the strike directly.', hint: 'Original contact response; preserves earlier project sounds.' }),
    Object.freeze({ id: 'felt', name: 'Felt', description: 'A yielding, rounded contact that rolls off sharp upper frequencies.', hint: 'Soft, broad contact for warm fundamentals and gentle attacks.' }),
    Object.freeze({ id: 'rubber', name: 'Rubber', description: 'An elastic, springy contact with a rounded attack and subtle contact ringing.', hint: 'Supple contact for rounded, bouncy percussion.' }),
    Object.freeze({ id: 'wood', name: 'Wood', description: 'A firm contact with a dry click and restrained high-frequency energy.', hint: 'Dry, firm contact for sticks, blocks, and hollow knocks.' }),
    Object.freeze({ id: 'nylon', name: 'Nylon', description: 'A smooth, firm tip with a clear attack and bright but rounded upper modes.', hint: 'Clean, focused contact between soft and brittle materials.' }),
    Object.freeze({ id: 'ceramic', name: 'Ceramic', description: 'A brittle, bright contact that sends fine, high-frequency detail into the body.', hint: 'Crisp contact for glassy, brittle attacks.' }),
    Object.freeze({ id: 'metal', name: 'Metal', description: 'A rigid, sharp contact with bright contact ringing and dense upper-frequency energy.', hint: 'Hard, bright contact for metallic edges and clear chimes.' })
  ]);
  const noiseColors = Object.freeze([
    Object.freeze({ id: 'white', name: 'White', description: 'Even broadband energy for snare wires and crisp strikes.' }),
    Object.freeze({ id: 'pink', name: 'Pink', description: 'A softer, balanced texture for brushes and natural friction.' }),
    Object.freeze({ id: 'brown', name: 'Brown', description: 'Low, warm energy for felt, skin, and deep impacts.' }),
    Object.freeze({ id: 'blue', name: 'Blue', description: 'Bright upper-frequency energy for sizzling metal.' }),
    Object.freeze({ id: 'velvet', name: 'Velvet', description: 'Sparse, evenly spaced random impulses for grainy brushes.' }),
    Object.freeze({ id: 'crackle', name: 'Crackle', description: 'Irregular impulses for rattles, grit, and brittle surfaces.' })
  ]);
  const groups = Object.freeze({
    resonance: Object.freeze([
      descriptor('pitchHz', 'Pitch', 20, 2000, true, 'Hz', 'The lowest resonant mode. Higher modes follow the selected material.'),
      descriptor('decay', 'Decay', 0.04, 4, true, 's', 'T60: the time for the lowest mode to fall by 60 dB. Damping shortens the upper modes.'),
      descriptor('tone', 'Brightness', 0, 1, false, '%', 'Balance low and high resonant modes without changing the material.'),
      descriptor('stiffness', 'Stiffness', 0, 1, false, '%', 'Spread the upper resonances away from their natural ratios. More stiffness produces metallic or prepared tones.'),
      descriptor('damping', 'Damping', 0, 1, false, '%', 'How quickly high-frequency resonances lose energy. Low values ring; high values sound dry.'),
      descriptor('position', 'Strike position', 0.02, 0.98, false, '%', 'Move the impact point across the resonator. Each position excites a different balance of modes.')
    ]),
    exciter: Object.freeze([
      descriptor('mallet', 'Mallet', 0, 1, false, '%', 'Strength of the short physical strike that excites the resonator.'),
      descriptor('hardness', 'Hardness', 0, 1, false, '%', 'Vary the firmness within the selected striking material. Softer contact favors the fundamental; harder contact excites upper modes.'),
      descriptor('strikeTime', 'Contact time', 0.0003, 0.03, true, 's', 'Base duration of the mallet contact; the selected material shapes its width. Short contact is sharp; longer contact softens the impact.'),
      descriptor('contactTexture', 'Contact texture', 0, 1, false, '%', 'Add material-colored friction to the contact itself. This follows the strike and stays separate from the noise envelope.'),
      descriptor('rebound', 'Rebound', 0, 1, false, '%', 'Allow the striker to bounce into smaller repeat contacts. At zero, every trigger produces one strike.'),
      descriptor('reboundTime', 'Bounce spacing', 0.002, 0.08, true, 's', 'Time between the first strike and its first rebound. Short spacing makes a buzz; longer spacing reveals separate bounces.'),
      descriptor('noise', 'Noise', 0, 1, false, '%', 'Amount of filtered noise exciting the resonator: brushes, wires, friction, or a rattle.'),
      descriptor('noiseAttack', 'Noise attack', 0.0005, 0.3, true, 's', 'Time for the noise exciter to rise to its peak.'),
      descriptor('noiseDecay', 'Noise decay', 0.005, 1, true, 's', 'Time for the noise excitation to fade after its attack.'),
      descriptor('noiseCutoff', 'Noise cutoff', 100, 16000, true, 'Hz', 'Low-pass cutoff shaping the noise before it reaches the resonator.'),
      descriptor('direct', 'Direct exciter', 0, 1, false, '%', 'Mix a little of the raw contact and noise into the output for extra attack and snare texture.')
    ]),
    motion: Object.freeze([
      descriptor('pitchEnv', 'Pitch bend', -24, 24, false, 'st', 'Pitch offset at the start of each strike. It settles to the voice pitch over the bend time.'),
      descriptor('pitchTime', 'Bend time', 0.002, 0.5, true, 's', 'How quickly the strike settles from its pitch bend to the fundamental.'),
      descriptor('variation', 'Variation', 0, 1, false, '%', 'Introduce small per-strike changes in tuning and contact position for a lively, organic feel.'),
      descriptor('velocityTone', 'Accent color', 0, 1, false, '%', 'How strongly accented steps excite the bright upper modes. Accents always play louder.'),
      descriptor('level', 'Level', 0, 1, false, '%', 'Voice level after the resonator and direct exciter are mixed.'),
      descriptor('pan', 'Pan', -1, 1, false, 'pan', 'Place the voice in the stereo field.')
    ])
  });
  const numeric = Object.freeze(Object.values(groups).flat());
  const modelIds = models.map((model) => model.id);
  const legacyModelIds = ['string', 'beam', 'marimba', 'drumhead', 'membrane', 'plate'];
  const materialIds = strikeMaterials.map((material) => material.id);
  const colorIds = noiseColors.map((color) => color.id);
  const newNumericKeys = ['contactTexture', 'rebound', 'reboundTime'];
  const legacyNumeric = numeric.filter((parameter) => !newNumericKeys.includes(parameter.key));
  const legacyTrackKeys = ['name', 'model', 'noiseColor', 'mute', 'solo', 'steps', ...legacyNumeric.map((parameter) => parameter.key)];
  const trackKeys = ['name', 'model', 'strikeMaterial', 'noiseColor', 'mute', 'solo', 'steps', ...numeric.map((parameter) => parameter.key)];
  const neutralContact = Object.freeze({ strikeMaterial: 'neutral', contactTexture: 0, rebound: 0, reboundTime: 0.018 });

  const common = Object.freeze({
    name: 'NEW VOICE', pitchHz: 220, decay: 0.55, tone: 0.5, stiffness: 0.1,
    damping: 0.35, position: 0.23, mallet: 0.8, hardness: 0.5, strikeTime: 0.002,
    noise: 0.1, noiseColor: 'pink', noiseAttack: 0.0005, noiseDecay: 0.035,
    noiseCutoff: 6000, direct: 0.1, pitchEnv: 0, pitchTime: 0.035,
    variation: 0.035, velocityTone: 0.3, level: 0.5, pan: 0, mute: false, solo: false,
    ...neutralContact
  });
  const voicing = Object.freeze({
    string: Object.freeze({ name: 'WIRE PLUCK', pitchHz: 220, decay: 1.25, tone: 0.52, stiffness: 0.12, damping: 0.22, position: 0.19, mallet: 0.76, hardness: 0.44, strikeTime: 0.0025, noise: 0.1, noiseDecay: 0.026, noiseCutoff: 4200, direct: 0.12, pitchTime: 0.022, variation: 0.025, velocityTone: 0.28, level: 0.5 }),
    beam: Object.freeze({ name: 'TIMBER BEAM', pitchHz: 520, decay: 0.42, tone: 0.54, stiffness: 0.18, damping: 0.52, position: 0.28, mallet: 0.88, hardness: 0.62, strikeTime: 0.0015, noise: 0.08, noiseDecay: 0.02, direct: 0.08, level: 0.48 }),
    marimba: Object.freeze({ name: 'FELT MARIMBA', pitchHz: 261.626, decay: 0.95, tone: 0.42, stiffness: 0.025, damping: 0.3, mallet: 0.95, hardness: 0.22, strikeTime: 0.0035, noise: 0.035, noiseColor: 'brown', noiseAttack: 0.0008, noiseDecay: 0.028, noiseCutoff: 2400, direct: 0.035, level: 0.48 }),
    drumhead: Object.freeze({ name: 'TAUT DRUMHEAD', pitchHz: 190, decay: 0.58, tone: 0.57, stiffness: 0.11, damping: 0.38, position: 0.38, mallet: 0.72, hardness: 0.57, strikeTime: 0.0015, noise: 0.38, noiseColor: 'white', noiseDecay: 0.09, noiseCutoff: 7200, direct: 0.22, pitchEnv: 3, level: 0.58 }),
    membrane: Object.freeze({ name: 'FELT KICK', pitchHz: 52, decay: 0.55, tone: 0.24, stiffness: 0.045, damping: 0.3, position: 0.15, mallet: 0.92, hardness: 0.36, strikeTime: 0.003, noise: 0.055, noiseColor: 'brown', noiseDecay: 0.026, noiseCutoff: 1800, direct: 0.16, pitchEnv: 14, level: 0.7 }),
    plate: Object.freeze({ name: 'BRUSHED PLATE', pitchHz: 620, decay: 0.8, tone: 0.7, stiffness: 0.68, damping: 0.18, position: 0.41, mallet: 0.72, hardness: 0.8, strikeTime: 0.0008, noise: 0.45, noiseColor: 'blue', noiseDecay: 0.045, noiseCutoff: 14000, direct: 0.2, variation: 0.05, level: 0.34 }),
    bell: Object.freeze({ name: 'CAST BELL', pitchHz: 440, decay: 1.8, tone: 0.6, stiffness: 0.06, damping: 0.19, position: 0.72, mallet: 0.78, hardness: 0.7, strikeTime: 0.0009, strikeMaterial: 'metal', contactTexture: 0.04, noise: 0.025, noiseColor: 'pink', noiseDecay: 0.018, noiseCutoff: 10500, direct: 0.03, variation: 0.018, velocityTone: 0.25, level: 0.38 }),
    bowl: Object.freeze({ name: 'SINGING BOWL', pitchHz: 196, decay: 2.4, tone: 0.48, stiffness: 0.04, damping: 0.13, position: 0.79, mallet: 0.93, hardness: 0.34, strikeTime: 0.0025, strikeMaterial: 'felt', contactTexture: 0.03, noise: 0.018, noiseColor: 'brown', noiseDecay: 0.03, noiseCutoff: 2200, direct: 0.015, variation: 0.018, velocityTone: 0.22, level: 0.42 }),
    tube: Object.freeze({ name: 'HOLLOW TUBE', pitchHz: 220, decay: 0.7, tone: 0.44, stiffness: 0.025, damping: 0.36, position: 0.16, mallet: 0.9, hardness: 0.57, strikeTime: 0.0018, strikeMaterial: 'wood', contactTexture: 0.07, noise: 0.06, noiseColor: 'pink', noiseDecay: 0.028, noiseCutoff: 3800, direct: 0.085, variation: 0.045, velocityTone: 0.3, level: 0.46 })
  });

  function defaults(model) {
    const id = modelIds.includes(model) ? model : 'membrane';
    return Object.assign({}, common, voicing[id], { model: id, steps: Array(16).fill(0) });
  }

  function normalizeTrack(track) {
    const input = isRecord(track) ? track : {};
    const result = defaults(input.model);
    if (typeof input.name === 'string') {
      const name = input.name.replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 32);
      if (name) result.name = name;
    }
    for (const parameter of numeric) {
      if (typeof input[parameter.key] === 'number' && Number.isFinite(input[parameter.key])) {
        result[parameter.key] = clamp(input[parameter.key], parameter.min, parameter.max);
      }
    }
    if (materialIds.includes(input.strikeMaterial)) result.strikeMaterial = input.strikeMaterial;
    if (colorIds.includes(input.noiseColor)) result.noiseColor = input.noiseColor;
    for (const key of ['mute', 'solo']) if (typeof input[key] === 'boolean') result[key] = input[key];
    if (Array.isArray(input.steps)) {
      result.steps = Array.from({ length: input.steps.length > 16 ? 32 : 16 }, (_, index) => {
        const value = input.steps[index];
        return typeof value === 'number' && Number.isFinite(value) ? clamp(Math.round(value), 0, 2) : 0;
      });
    }
    return result;
  }

  const exactKeys = (object, keys) => isRecord(object) && Object.keys(object).length === keys.length
    && keys.every((key) => Object.prototype.hasOwnProperty.call(object, key));
  const validSteps = (steps) => Array.isArray(steps) && [16, 32].includes(steps.length)
    && Array.from(steps).every((step) => Number.isInteger(step) && step >= 0 && step <= 2);

  function validTrackShape(track, keys, acceptedModels, parameters) {
    return exactKeys(track, keys) && typeof track.name === 'string' && track.name.trim().length > 0
      && track.name.length <= 32 && !/[\u0000-\u001f\u007f]/.test(track.name)
      && acceptedModels.includes(track.model) && colorIds.includes(track.noiseColor)
      && typeof track.mute === 'boolean' && typeof track.solo === 'boolean' && validSteps(track.steps)
      && parameters.every((parameter) => finite(track[parameter.key], parameter.min, parameter.max));
  }

  function validateTrack(track) {
    return validTrackShape(track, trackKeys, modelIds, numeric) && materialIds.includes(track.strikeMaterial);
  }

  function validateLegacyTrack(track) {
    return validTrackShape(track, legacyTrackKeys, legacyModelIds, legacyNumeric);
  }

  function validateProject(project) {
    if (!exactKeys(project, ['app', 'version', 'state', 'banks', 'bank', 'selected', ...(project?.version === 4 ? ['bankLocks'] : [])]) || project.app !== 'TINE' || ![1, 2, 3, 4].includes(project.version)) return false;
    const state = project.state;
    if (!exactKeys(state, ['name', 'bpm', 'swing', 'drive', 'space', 'master', 'tracks', ...(project.version >= 3 ? ['stepCount'] : []), ...(project.version === 4 ? ['chain'] : []), ...(state?.musicLabPattern === undefined ? [] : ['musicLabPattern'])])) return false;
    if (project.version >= 3 && ![16, 32].includes(state.stepCount)) return false;
    if (state.musicLabPattern !== undefined) {
      try {
        const overlay = state.musicLabPattern;
        if (!overlay || !window.MusicLabPatternSchema || !isRecord(overlay.voiceMap)) return false;
        const pattern = window.MusicLabPatternSchema.normalize(overlay.pattern);
        if (pattern.voices.some(voice => !/^voice-[0-7]$/.test(overlay.voiceMap[voice.id]))) return false;
      } catch (_) { return false; }
    }
    if (typeof state.name !== 'string' || !state.name.trim() || state.name.length > 80 || /[\u0000-\u001f\u007f]/.test(state.name)) return false;
    if (!finite(state.bpm, 40, 240) || !finite(state.swing, 0, 0.6) || !['drive', 'space', 'master'].every((key) => finite(state[key], 0, 1))) return false;
    const trackValidator = project.version === 1 ? validateLegacyTrack : validateTrack;
    if (!Array.isArray(state.tracks) || state.tracks.length !== 8 || !Array.from(state.tracks).every(trackValidator)) return false;
    if (!Array.isArray(project.banks) || project.banks.length !== 4 || !Array.from(project.banks).every((bank) => Array.isArray(bank) && bank.length === 8 && Array.from(bank).every(validSteps))) return false;
    if (project.version === 4 && (!validChain(state.chain, state.stepCount) || !Array.isArray(project.bankLocks) || project.bankLocks.length !== 4 || !project.bankLocks.every((locks, bank) => Array.isArray(locks) && locks.length === 8 && locks.every((steps, voice) => Array.isArray(steps) && steps.length === project.banks[bank][voice].length && Array.from(steps).every(validLocks))))) return false;
    const patterns = [...state.tracks.map((track) => track.steps), ...project.banks.flat()];
    if ((project.version < 3 && patterns.some((steps) => steps.length !== 16)) || (state.stepCount === 32 && patterns.some((steps) => steps.length !== 32))) return false;
    return Number.isInteger(project.bank) && project.bank >= 0 && project.bank <= 3
      && Number.isInteger(project.selected) && project.selected >= 0 && project.selected <= 7;
  }

  function upgradeProject(project) {
    if (!validateProject(project)) throw new Error('Invalid CLATTER project.');
    const upgraded = JSON.parse(JSON.stringify(project));
    if (upgraded.version === 1) {
      upgraded.state.tracks = upgraded.state.tracks.map((track) => Object.assign({}, track, neutralContact));
      upgraded.version = 2;
    }
    if (upgraded.version === 2) { upgraded.state.stepCount = 16; upgraded.version = 3; }
    if (upgraded.version === 3) {
      upgraded.state.chain = defaultChain();
      upgraded.bankLocks = upgraded.banks.map(bank => bank.map(steps => steps.map(() => ({}))));
      upgraded.version = 4;
    }
    return upgraded;
  }

  const lockRanges = Object.freeze({ cutoff: [20, 20000], resonance: [.1, 20], decay: [.005, 10], pan: [-1, 1], level: [0, 1], tone: [0, 1], drive: [0, 1] });
  function validLocks(value) {
    return isRecord(value) && Object.keys(value).every(key => Object.hasOwn(lockRanges, key) && finite(value[key], ...lockRanges[key]));
  }
  function normalizeLocks(value) {
    if (value === undefined) return {};
    if (!validLocks(value)) throw new Error('Invalid CLATTER step locks.');
    return Object.assign({}, value);
  }
  function defaultChain() { return { enabled: false, loop: true, entries: [] }; }
  function emptyLocks(length = 16) { return Array.from({ length: 8 }, () => Array.from({ length }, () => ({}))); }
  function validChain(chain, stepCount = 16) {
    return exactKeys(chain, ['enabled', 'loop', 'entries']) && typeof chain.enabled === 'boolean' && typeof chain.loop === 'boolean'
      && Array.isArray(chain.entries) && chain.entries.length <= 32 && (!chain.enabled || chain.entries.length > 0)
      && new Set(chain.entries.map(entry => entry?.id)).size === chain.entries.length
      && chain.entries.every(entry => exactKeys(entry, ['id', 'bank', 'repeats']) && typeof entry.id === 'string' && /^[a-zA-Z0-9_-]{1,64}$/.test(entry.id) && Number.isInteger(entry.bank) && entry.bank >= 0 && entry.bank <= 3 && Number.isInteger(entry.repeats) && entry.repeats >= 1 && entry.repeats <= 16)
      && chain.entries.reduce((sum, entry) => sum + entry.repeats * stepCount / 4, 0) <= 256;
  }
  function nextSequenceFrame(project, previous) {
    const chain = project.state.chain || defaultChain(), length = project.state.stepCount === 32 ? 32 : 16;
    if (!chain.enabled || !chain.entries.length) return { chain: false, bank: project.bank, entry: 0, entryId: null, repeat: 1, repeats: 1, length };
    let index = previous?.chain ? chain.entries.findIndex(entry => entry.id === previous.entryId) : -1, repeat = 1;
    if (index < 0) {
      index = previous?.chain ? previous.entry : 0;
      // Removing the playing entry hands off to its successor at the same
      // position, rather than unexpectedly returning to the first pattern.
      if (index >= chain.entries.length) { if (!chain.loop) return null; index = 0; }
    }
    else if (previous.repeat < chain.entries[index].repeats) repeat = previous.repeat + 1;
    else if (++index >= chain.entries.length) { if (!chain.loop) return null; index = 0; }
    const entry = chain.entries[index];
    return { chain: true, bank: entry.bank, entry: index, entryId: entry.id, repeat, repeats: entry.repeats, length };
  }
  function sequencerPattern(project, options = {}) {
    const s = project.state, stepCount = s.stepCount === 32 ? 32 : 16, scope = options.scope;
    if (scope !== undefined && !['pattern', 'chain', 'voice', 'sequence'].includes(scope)) throw new Error('Choose the current pattern, chain, or selected voice.');
    const useChain = scope === 'chain' || ((scope === undefined || scope === 'sequence') && s.chain?.enabled);
    const entries = useChain ? s.chain?.entries || [] : [{ bank: project.bank, repeats: 1 }];
    if (!entries.length) throw new Error('Add a pattern to the CLATTER chain first.');
    const lengthBeats = entries.reduce((total, entry) => total + entry.repeats * stepCount / 4, 0);
    if (lengthBeats > 256) throw new Error('The chain is longer than 256 beats. Use fewer repeats.');
    const voices = s.tracks.map((track, index) => ({ id: 'voice-' + index, name: track.name, pitch: 36 + index })), notes = [];
    const solo = s.tracks.some(track => track.solo), selected = options.voice === undefined ? project.selected : options.voice;
    if (scope === 'voice' && (!Number.isInteger(selected) || selected < 0 || selected > 7)) throw new Error('Choose a CLATTER voice from 1 to 8.');
    let offset = 0, ordinal = 0;
    for (const entry of entries) for (let repeat = 0; repeat < entry.repeats; repeat++) {
      s.tracks.forEach((track, index) => {
        if (scope === 'voice' ? index !== selected : track.mute || solo && !track.solo) return;
        project.banks[entry.bank][index].slice(0, stepCount).forEach((hit, step) => {
          if (!hit) return;
          if (notes.length >= 4096) throw new Error('This sequence exceeds 4,096 shared notes. Use fewer hits or repeats.');
          const beat = offset + step / 4 + (step % 2 ? s.swing / 4 : 0), locks = normalizeLocks(project.bankLocks?.[entry.bank]?.[index]?.[step]);
          notes.push({ id: 'note-' + ordinal++, voice: voices[index].id, pitch: voices[index].pitch, beat, duration: Math.min(.25, lengthBeats - beat), velocity: hit === 2 ? 1 : .73, probability: 1, ...(Object.keys(locks).length ? { locks } : {}) });
        });
      });
      offset += stepCount / 4;
    }
    const packet = { format: 'musiclab-pattern', version: 1, name: s.name + (useChain ? ' · chain' : ' · CLATTER'), sourceApp: 'tine', kind: 'drums', tempo: s.bpm, swing: 0, lengthBeats, meter: [4, 4], voices, notes, seed: 0x5A17C0DE };
    return window.MusicLabPatternSchema ? window.MusicLabPatternSchema.normalize(packet) : packet;
  }

  function format(parameter, value) {
    const control = typeof parameter === 'string' ? numeric.find((entry) => entry.key === parameter) : parameter;
    if (!control || typeof value !== 'number' || !Number.isFinite(value)) return '—';
    const readable = (number, digits) => String(Number(number.toFixed(digits)));
    switch (control.unit) {
      case 'Hz': return value >= 1000 ? readable(value / 1000, 2) + ' kHz' : readable(value, value < 100 ? 1 : 0) + ' Hz';
      case 's': return value < 1 ? readable(value * 1000, value < 0.01 ? 1 : 0) + ' ms' : readable(value, 2) + ' s';
      case '%': return Math.round(value * 100) + '%';
      case 'st': return (value > 0 ? '+' : '') + readable(value, 1) + ' st';
      case 'pan': return Math.abs(value) < 0.005 ? 'Center' : Math.round(Math.abs(value) * 100) + (value < 0 ? ' L' : ' R');
      default: return readable(value, 2);
    }
  }

  window.TineModel = Object.freeze({ models, strikeMaterials, noiseColors, groups, defaults, normalizeTrack, validateTrack, validateProject, upgradeProject, format, lockRanges, validLocks, normalizeLocks, defaultChain, emptyLocks, validChain, nextSequenceFrame, sequencerPattern });
}());
