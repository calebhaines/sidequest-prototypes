# Sidequest

Six original RPG worlds, with eight browser-playable versions. **Velvet Static** and **Hidden Ember** each have a pixel-art version and a new 3D version. The four earlier prototypes remain available with their existing gameplay.

[Play the gallery](https://calebhaines.github.io/sidequest-prototypes/?v=0.6.0) · [Velvet Static 3D](https://calebhaines.github.io/sidequest-prototypes/?v=0.6.0#play-lynch-3d) · [Hidden Ember 3D](https://calebhaines.github.io/sidequest-prototypes/?v=0.6.0#play-shinobi-3d)

## The worlds

- **Velvet Static** — a Lynch-inspired county mystery with contradictory witnesses, a paper mill, red-curtain theater, lakeside observatory, ferry marshes, and waking and dream realities. Available in 2D and 3D.
- **Hidden Ember** — a Naruto-inspired original shinobi adventure with hidden villages, orange rooftops, cedar forests, clan outposts, waterfall training, chakra, and three active jutsus. Available in 2D and 3D.
- **Moss & Myth** — woodland fantasy, forest folk, and forgotten magic.
- **Neon Afterglow** — cyberpunk streets, conspiracies, and faction choices.
- **The Dustlands** — desert salvage and a settlement running out of water.
- **Borrowed Sky** — surreal suburbs, everyday magic, and a missing Thursday.

The 3D versions use solid characters, buildings, landscapes, and furniture with a perspective camera, lighting, and shaded geometry without outlines. They use the same story and gameplay engine as their 2D counterparts: real-time combat, branching conversations, remembered replies, loot, levels, main quests, side stories, travel, and three endings per finalist.

Each finalist covers **4800 × 3456 simulation pixels**, nine times its original area, with **14 characters**, **six main objectives**, **three side stories**, and **six travel stops**. Every enclosed building is enterable in both versions. Velvet Static has **31 interiors**, including six motel rooms, three railway coaches, the ferry wheelhouse, diner, theater, mill, and observatory. Hidden Ember has **25 interiors**, including ramen shops, homes, leadership tower, clinic, archives, workshops, inns, and border offices. Inspect objects and meet residents indoors; Velvet Static's dream crossings continue inside.

These are playable concept adventures for developing a larger RPG. An adventure starts fresh when you reopen a version. Gallery favorites and your shortlist are saved locally in your browser.

## Download and run

Download [**sidequest-prototypes.zip**](https://raw.githubusercontent.com/calebhaines/sidequest-prototypes/v0.6.0/docs/sidequest-prototypes.zip), extract it, and open **sidequest/PLAY.html** in your browser. Or save [**sidequest-play.html**](https://raw.githubusercontent.com/calebhaines/sidequest-prototypes/v0.6.0/docs/sidequest-play.html) and open the saved file. Both links are fixed to **v0.6.0**.

The standalone HTML includes all eight playable versions, artwork, 3D rendering code, previews, and fonts. It works offline without an installation, account, or server. The 3D versions require a browser with WebGL enabled. Three.js is bundled locally; playing does not fetch libraries, models, or other assets from external services.

The ZIP also contains the production website and editable source. For development, install Node.js 20.19+ or 22.12+, then run:

```sh
npm ci
npm run dev
```

Open the URL printed by Vite. To build or preview the production website:

```sh
npm run build
npm run preview
```

To regenerate the downloadable ZIP and HTML, run `npm run package` after installing dependencies. Packaging also requires Python 3. Generated downloads are placed in `downloads/` and `public/downloads/`.

## Controls

**WASD / arrows** move; **Shift** sprints; **E / Enter** talks, inspects, enters doors, or leaves at an indoor exit; **Space** attacks; **M** opens the map; **T** opens discovered travel stops in the finalists; **Escape** closes dialogue or the map, or returns to the gallery. Touch controls and clickable ability buttons are available. Ambient sound is optional.

In 3D, **drag the game view** to orbit the camera and **scroll** to zoom. On-screen camera buttons also rotate, zoom, and reset the view. Movement follows the current camera direction; resetting the camera restores the initial north-facing view. The world map and room floor plans remain top-down views.

In **Velvet Static**, **Q** crosses between waking and dream, including indoors. **Space** repels threats with a camera flash.

In **Hidden Ember**, **1** casts Ember Release, **2** creates a Shadow Clone, and **3** uses Substitution. **Space** throws a kunai. Chakra replenishes over time. Ask Sora about the watchtower passphrase to pursue a peaceful route.

Approach a marked doorstep and press **E** to enter. Inside, use **E** to inspect objects, speak to residents, or leave at the marked exit. Quest directions lead to the appropriate building for indoor clues. **M** shows the outdoor world with your location at the entrance; **Room floor plan** shows the local room and exit. **T** can take you from an interior to a discovered outdoor travel stop. Progress and dialogue decisions carry through these transitions during the adventure.

Accept side stories through conversations, then track one under **Other stories** in the sidebar. Use gallery links such as `#play-lynch-3d`, `#play-shinobi-3d`, `#play-lynch`, or `#play-shinobi` to open a specific version.

## Credits

World design, pixel artwork, and 3D models are original. Three.js is distributed under the MIT License; its license text is included in `public/licenses/three-MIT.txt` and the downloads. DM Sans and Space Grotesk are bundled under the SIL Open Font License 1.1, with notices in `public/fonts/`.
