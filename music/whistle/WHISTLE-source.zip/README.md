# WHISTLE

A loop, not a sample. WHISTLE is a self-oscillating feedback and distortion
unit for Kitchen, numbered **K—15** on the equipment list.

Noise is pushed through a waveshaper burner, damped at the vent, then returned
through a tuned spout delay until the loop finds its own note. Nothing is
pre-rendered: every sound it makes is generated live in the Web Audio graph.

## Files

- `index.html` — the whole instrument: markup, styles and engine in one
  self-contained file, with the Kilter Condensed face embedded. No external
  assets, no runtime dependencies, no samples.
- `README.md` — this file.

The published copy lives at `music/whistle/index.html`; `npm run music:sync`
copies it into `public/music/` and `docs/music/`. This instrument has no
`build.py` stage because the single file is already the build output.

## Signal path

```
noise ──► burner (waveshaper) ──► vent (bandpass) ──► kettle (master) ──► limiter ──► out
                    ▲                   │
                    │                   ▼
                pressure ◄──── spout delay ◄──── damping (lowpass)
```

The loop is legal in Web Audio because the cycle contains a `DelayNode`.
Feedback is capped at 0.92 and the output passes a `DynamicsCompressor` before
the destination so a runaway setting cannot reach full scale.

## Controls

| Control | What it does |
| --- | --- |
| **BURNER** | Drive into the waveshaper, 1× to 25×. Adds harmonics, then fold. |
| **PRESSURE** | Loop feedback, 0–92%. Above roughly 70% it self-oscillates. |
| **SPOUT** | Loop period, 2–90 ms. Retunes the live loop while a pitch is held. |
| **VENT** | Loop damping, 280 Hz to 8 kHz. Lower is darker and more stable. |
| **GLASS** | Bandpass resonance, Q 0.7–22.7. |
| **KETTLE** | Output level. |

Eight pitch pads (110–293.66 Hz) set the loop period so the kettle whistles at
that note. **SHRIEK** momentarily raises pressure and excites the loop;
**HOLD** keeps the last pitch latched; **VENT** ramps feedback to zero and
lets the loop settle.

Keyboard: `A S D F G H J K` play the pads, `Space` shrieks. Knobs respond to
pointer drag and to arrow keys when focused.

## Notes

- Audio starts on the first pointer or key gesture, as browsers require.
- The scope reads an `AnalyserNode`; it draws an idle line until the loop runs.
- Respects `prefers-reduced-motion` by disabling transitions.
