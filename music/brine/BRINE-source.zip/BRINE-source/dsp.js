/* BRINE · six-voice DCO / OTA / stereo BBD synthesis. Original software model. */
(function(scope){
  'use strict';
  function createBrineDSP(){
    'use strict';
    const TAU=2*Math.PI,OS=2,VOICE_COUNT=6;
    const specifications={
      model:['60','106'],range:['16','8','4'],saw:[false,true],pulse:[false,true],sub:[false,true],pwmSource:['manual','lfo','env'],pwmAmount:[0,1,.28],dcoLfo:[0,1,0],subLevel:[0,1,.2],noiseLevel:[0,1,0],
      hpf:[0,1,0],cutoff:[20,20000,1700],resonance:[0,1,.12],envAmount:[0,1,.22],envPolarity:['positive','negative'],filterLfo:[0,1,0],keyTrack:[0,1,.5],
      envAttack:[.001,3,.28],envDecay:[.001,12,1.2],envSustain:[0,1,.78],envRelease:[.0015,12,1.3],ampMode:['env','gate'],ampLevel:[0,1,.8],
      lfoRate:[.1,30,.42],lfoDelay:[0,3,0],lfoTriggerMode:['auto','manual'],chorus:['off','I','II','I+II'],
      volume:[0,1,.7],masterTune:[-50,50,0],modWheel:[0,1,0],bendRange:[0,12,2],bendFilter:[0,1,0],
      age:[0,1,.25],chorusNoise:[0,1,.12],chorusDrive:[0,1,.25],chorusWidth:[0,1,1],velocityAmount:[0,1,0],glide:[0,5,0]
    };
    const defaults={};for(const key of Object.keys(specifications)){const r=specifications[key];defaults[key]=typeof r[0]==='number'?r[2]:typeof r[0]==='boolean'?false:r[0];}Object.assign(defaults,{range:'8',saw:true,pulse:true,sub:true,pwmSource:'lfo',chorus:'I'});
    const keys=Object.keys(specifications),clamp=(x,a,b,f=a)=>Number.isFinite(x)?Math.max(a,Math.min(b,x)):f,frac=x=>x-Math.floor(x);
    function normalize(raw){const source=raw&&typeof raw==='object'?(raw.synth&&typeof raw.synth==='object'?raw.synth:raw):{},out={};for(const key of keys){const r=specifications[key],v=source[key];out[key]=typeof r[0]==='number'?clamp(v,r[0],r[1],r[2]):typeof r[0]==='boolean'?typeof v==='boolean'?v:defaults[key]:r.includes(v)?v:defaults[key];}out.hpf=Math.round(out.hpf*3)/3;if(out.model==='106'){if(out.pwmSource==='env')out.pwmSource='manual';if(out.chorus==='I+II')out.chorus='off';out.envAttack=Math.max(.0015,out.envAttack);out.envDecay=Math.max(.0015,out.envDecay);out.envRelease=Math.max(.0015,out.envRelease);}else{out.lfoRate=clamp(out.lfoRate,.3,20,.42);out.lfoDelay=Math.min(1.5,out.lfoDelay);out.envRelease=Math.max(.002,out.envRelease);}return out;}
    function estimateTail(patch){const p=normalize(patch);return Math.min(30,Math.max(.12,(p.ampMode==='env'?p.envRelease*2.5:.03)+(p.chorus==='off'?.05:.35)));}
    function hash(x){x=Math.imul(x^(x>>>16),0x7feb352d);x=Math.imul(x^(x>>>15),0x846ca68b);return(x^(x>>>16))>>>0;}
    const signed=x=>hash(x)/2147483648-1;
    const E_SIZE=2048,E=new Float64Array(E_SIZE+1),POW=new Float64Array(49);
    for(let i=0;i<=E_SIZE;i++)E[i]=Math.pow(2,i/E_SIZE);for(let i=0;i<49;i++)POW[i]=Math.pow(2,i-24);
    function exp2(x){x=Math.max(-24,Math.min(24,x));const n=Math.floor(x),at=(x-n)*E_SIZE,i=at|0;return POW[n+24]*(E[i]+(E[i+1]-E[i])*(at-i));}
    function soft(x){if(x>=3)return 1;if(x<=-3)return-1;const q=x*x;return x*(27+q)/(27+9*q);}
    function slope(x){if(x>=3||x<=-3)return 0;const q=x*x,d=27+9*q;return(729-162*q+9*q*q)/(d*d);}
    const W_SIZE=4096,W=new Float64Array(W_SIZE+1);for(let i=0;i<=W_SIZE;i++)W[i]=Math.tan(Math.PI*.45*i/W_SIZE);
    function warp(x){const at=Math.max(0,Math.min(.43,x))*W_SIZE/.45,i=at|0;return W[i]+(W[i+1]-W[i])*(at-i);}
    class Envelope{
      constructor(rate=48000,p={}){this.rate=rate;this.value=0;this.stage=0;this.set(p);}
      set(p={}){this.model=p.model==='106'?'106':'60';const minimum=this.model==='106'?.0015:.001;this.attack=clamp(p.attack,minimum,3,.28);this.decay=clamp(p.decay,minimum,12,1.2);this.sustain=clamp(p.sustain,0,1,.78);this.release=clamp(p.release,this.model==='106'?.0015:.002,12,1.3);this.asymptote=this.model==='106'?1.35:1.3;this.a=Math.exp(-Math.log(this.asymptote/(this.asymptote-1))/(this.attack*this.rate));this.d=Math.exp(-Math.log(1000)/(this.decay*this.rate));this.r=Math.exp(-Math.log(1000)/(this.release*this.rate));}
      gate(down){if(down)this.stage=1;else if(this.stage)this.stage=4;}
      tick(){if(this.stage===1){this.value=this.asymptote+(this.value-this.asymptote)*this.a;if(this.value>=1){this.value=1;this.stage=2;}}else if(this.stage===2){this.value=this.sustain+(this.value-this.sustain)*this.d;if(this.value<=this.sustain+1e-6){this.value=this.sustain;this.stage=3;}}else if(this.stage===3)this.value=this.sustain+(this.value-this.sustain)*.995;else if(this.stage===4){this.value*=this.r;if(this.value<1e-7){this.value=0;this.stage=0;}}}
      process(){this.tick();return this.value;}
      reset(){this.value=0;this.stage=0;}
    }
    // One timing counter resets both analog ramp and pulse; a flip-flop divides
    // it for the sub. Moving PWM and natural edges receive causal event BLEPs.
    class DCO{
      constructor(phase=0){this.io=new Float64Array(6);this.phase=frac(phase/2)*2;this.lastWidth=.5;this.sawCarry=this.pulseCarry=this.subCarry=0;this.saw=this.pulse=this.sub=0;}
      reset(phase=0){this.phase=frac(phase/2)*2;this.lastWidth=.5;this.sawCarry=this.pulseCarry=this.subCarry=0;}
      _edge(amplitude,time,kind){const t=1-time,now=amplitude*.5*t*t,next=-amplitude*.5*time*time;if(kind===0){this.saw+=now;this.sawCarry+=next;}else if(kind===1){this.pulse+=now;this.pulseCarry+=next;}else{this.sub+=now;this.subCarry+=next;}}
      _pulseEdge(phase,inc,start,end,width,dw){const relative=inc-dw;if(relative===0||end<=start)return;const time=start-(phase-width-dw*start)/relative;if(time>start&&time<=end)this._edge(relative>0?-2:2,time,1);}
      sample(increment,width=.5){this.io[0]=clamp(increment,0,.4,0);this.io[1]=clamp(width,.05,.95,.5);this.tick();return this.io;}
      tick(){const inc=this.io[0],width=this.io[1],phase=this.phase,p=phase>=1?phase-1:phase,prior=this.lastWidth,dw=width-prior;this.lastWidth=width;this.saw=2*p-1+this.sawCarry;this.pulse=(p<prior?1:-1)+this.pulseCarry;this.sub=(phase<1?1:-1)+this.subCarry;this.sawCarry=this.pulseCarry=this.subCarry=0;
        if(inc>0){const wrap=(1-p)/inc;if(wrap<=1){this._edge(-2,wrap,0);this._edge(2,wrap,1);this._edge(phase<1?-2:2,wrap,2);}this._pulseEdge(p,inc,0,Math.min(1,wrap),prior,dw);if(wrap<1)this._pulseEdge(0,inc,wrap,1,prior,dw);this.phase=phase+inc;if(this.phase>=2)this.phase-=2;}
        this.io[2]=this.saw;this.io[3]=this.pulse;this.io[4]=this.sub;this.io[5]=this.phase;
      }
    }
    // Four OTA integrator stages with an implicit nonlinear resonance loop.
    // Input/headroom and feedback limiting are reduced-order circuit models,
    // not per-component electrical calibration of a particular IR3109 unit.
    class Filter{
      constructor(rate=96000){this.rate=rate;this.z=new Float64Array(4);this.io=new Float64Array(4);this.cutoff=NaN;this.resonance=NaN;this.age=0;this.set(1000,.1);this.reset(1e-10);}
      set(cutoff,resonance){this.io[1]=clamp(cutoff,5,this.rate*.43,1000);this.io[2]=clamp(resonance,0,1,.1);this.configure();}
      configure(){const cutoff=this.io[1],res=this.io[2];if(cutoff!==this.cutoff){this.cutoff=cutoff;const g=warp(cutoff/this.rate);this.G=g/(1+g);this.C=1-this.G;this.G2=this.G*this.G;this.G3=this.G2*this.G;this.G4=this.G3*this.G;}if(res!==this.resonance){this.resonance=res;this.k=4.4*res*res;}}
      process(input,cutoff=this.cutoff,resonance=this.resonance){this.io[0]=input;this.io[1]=clamp(cutoff,5,this.rate*.43,1000);this.io[2]=clamp(resonance,0,1,.1);this.tick();return this.io[3];}
      tick(){if(this.io[1]!==this.cutoff||this.io[2]!==this.resonance)this.configure();const z=this.z,G=this.G,C=this.C,S0=C*z[0],S1=C*z[1],S2=C*z[2],S3=C*z[3],S=this.G3*S0+this.G2*S1+G*S2+S3,k=this.k,g4=this.G4,input=soft(this.io[0]*.55)/.55;let u=(input-k*S)/(1+k*g4);
        if(k>0)for(let pass=0;pass<2;pass++){const out=g4*u+S,scaled=out/.78,fb=soft(scaled)*.78;u-=(u+k*fb-input)/(1+k*g4*slope(scaled));}
        const y0=G*u+S0,y1=G*y0+S1,y2=G*y1+S2,y3=G*y2+S3;z[0]=2*y0-z[0];z[1]=2*y1-z[1];z[2]=2*y2-z[2];z[3]=2*y3-z[3];this.io[3]=y3;
      }
      reset(seed=0){this.z.fill(0);this.z[0]=seed;this.io[3]=0;}
    }
    class Highpass{
      constructor(rate=48000){this.rate=rate;this.position=-1;this.model='';this.state=0;this.low=0;this.value=0;this.set(0,'60');}
      set(position,model='60'){position=Math.round(clamp(position,0,1,0)*3);if(position===this.position&&model===this.model)return;this.position=position;this.model=model;const frequencies=model==='106'?[0,0,225,550]:[0,220,480,1030];this.cutoff=frequencies[position];this.a=Math.exp(-TAU*Math.max(1,this.cutoff)/this.rate);this.bassA=1-Math.exp(-TAU*105/this.rate);}
      process(input){this.low+=this.bassA*(input-this.low);if(this.cutoff===0){this.state=input;this.value=this.model==='106'&&this.position===0?input+this.low:input;return this.value;}const value=this.a*(this.value+input-this.state);this.state=input;this.value=value;return value;}
      reset(){this.state=this.low=this.value=0;}
    }
    const POST_STEPS=256,postCache=new Map(),POST_ROWS=[0,0,1,1,2,2,2,2,3,3,3,3,4,4,4,4,4],POST_COLS=[0,1,0,1,0,1,2,3,0,1,2,3,0,1,2,3,4];
    function multiply(a,b,out){for(let row=0;row<5;row++)for(let col=0;col<5;col++){let value=0;for(let k=0;k<5;k++)value+=a[row*5+k]*b[k*5+col];out[row*5+col]=value;}}
    function postTable(rate){
      if(postCache.has(rate))return postCache.get(rate);
      // Two ideal unity-gain Sallen-Key sections from the service diagram,
      // followed by the equivalent BBD output clock-rejection RC pole.
      const w1=1/(22000*Math.sqrt(820e-12*680e-12))/rate,Q1=.5*Math.sqrt(820/680),w2=1/(22000*Math.sqrt(1800e-12*270e-12))/rate,Q2=.5*Math.sqrt(1800/270),R=1/(2/3300+1/47000),gamma=1/(R*2.2e-9)/rate;
      const A=new Float64Array(25),step=new Float64Array(25),term=new Float64Array(25),work=new Float64Array(25),B=new Float64Array(25);A[1]=1;A[5]=-w1*w1;A[6]=-w1/Q1;A[13]=1;A[15]=w2*w2;A[17]=-w2*w2;A[18]=-w2/Q2;A[22]=gamma;A[24]=-gamma;
      for(let i=0;i<25;i++)B[i]=A[i]/POST_STEPS;for(let i=0;i<5;i++)step[i*5+i]=term[i*5+i]=1;
      // The largest normalized small step is <0.08 even at an 8 kHz output;
      // eight Taylor terms put exp(A*h) beneath floating-point precision.
      for(let order=1;order<=8;order++){multiply(term,B,work);for(let i=0;i<25;i++){term[i]=work[i]/order;step[i]+=term[i];}}
      const table=new Float64Array((POST_STEPS+1)*34),M=new Float64Array(25),derivative=new Float64Array(25);for(let i=0;i<5;i++)M[i*5+i]=1;
      for(let i=0;i<=POST_STEPS;i++){multiply(B,M,derivative);for(let j=0;j<17;j++){const at=POST_ROWS[j]*5+POST_COLS[j];table[i*34+j]=M[at];table[i*34+17+j]=derivative[at];}multiply(step,M,work);M.set(work);}
      if(postCache.size>=4)postCache.delete(postCache.keys().next().value);postCache.set(rate,table);return table;
    }
    // MN3009 equivalent transport: actual nonuniform clock events shift a
    // 256-bucket ring, rather than reading a moving fractional audio delay tap.
    class Chorus{
      constructor(rate=48000,p={}){this.rate=rate;this.io=new Float64Array(3);this.phase=0;this.mix=0;this.clockL=this.clockR=0;this.indexL=this.indexR=0;this.bucketL=new Float64Array(256);this.bucketR=new Float64Array(256);this.pre=new Float64Array(4);this.preCoefficients=new Float64Array(10);this.postTransition=postTable(rate);this.postCoefficients=new Float64Array(17);this.postL=new Float64Array(5);this.postR=new Float64Array(5);this.previous=0;this.heldL=this.heldR=0;this.noiseSeed=0x4252494e;this.set(p);}
      set(p={}){this.model=p.model||'60';this.mode=this.model==='106'&&p.chorus==='I+II'?'off':p.chorus||'off';this.width=clamp(p.chorusWidth,0,1,1);this.noise=clamp(p.chorusNoise,0,1,.12);this.drive=clamp(p.chorusDrive,0,1,.25);this.age=clamp(p.age,0,1,.25);this.target=this.mode==='off'?0:1;this.lfoHz=this.mode==='II'?1/1.2:this.mode==='I+II'?1:.5;this.baseClock=this.model==='106'?32000:30000;this.depth=this.mode==='I+II'?.25*.08:.25;const f0=1/(TAU*22000*Math.sqrt(820e-12*680e-12)),Q=.5*Math.sqrt(820/680),f1=1/(TAU*22000*Math.sqrt(1800e-12*270e-12)),Q1=.5*Math.sqrt(1800/270);for(let section=0;section<2;section++){const frequency=section?f1:f0,quality=section?Q1:Q,w=TAU*Math.min(frequency,this.rate*.22)/this.rate,c=Math.cos(w),a=Math.sin(w)/(2*quality),a0=1+a,at=section*5;this.preCoefficients[at]=(1-c)*.5/a0;this.preCoefficients[at+1]=(1-c)/a0;this.preCoefficients[at+2]=this.preCoefficients[at];this.preCoefficients[at+3]=-2*c/a0;this.preCoefficients[at+4]=(1-a)/a0;}this.filterHz=f0;this.filterQ=Q;this.filterHz2=f1;this.filterQ2=Q1;this.clockPoleHz=1/(TAU*(1/(2/3300+1/47000))*2.2e-9);this.mixA=1-Math.exp(-1/(this.rate*.005));}
      process(input){this.io[0]=input;this.tick();return this.io;}
      _post(){const z=this.postState,input=this.postHeld;
        // At normal oversampled rates the exact positive-zero state is a
        // fixed point. Skip only its dead reconstruction arithmetic; tick
        // still advances every BBD clock, bucket, phase and noise sample.
        // Low rates and any signed/nonzero state keep the original path.
        if(this.rate>=64000&&Object.is(input,0)&&Object.is(z[0],0)&&Object.is(z[1],0)&&Object.is(z[2],0)&&Object.is(z[3],0)&&Object.is(z[4],0))return;
        const q0=z[0]-input,q1=z[1],q2=z[2]-input,q3=z[3],q4=z[4]-input,at=Math.max(0,Math.min(1,this.postDelta))*POST_STEPS,i=Math.min(POST_STEPS-1,at|0),t=at-i,t2=t*t,t3=t2*t,a=2*t3-3*t2+1,b=t3-2*t2+t,c=-2*t3+3*t2,d=t3-t2,T=this.postTransition,C=this.postCoefficients,base=i*34;for(let j=0;j<17;j++)C[j]=a*T[base+j]+b*T[base+17+j]+c*T[base+34+j]+d*T[base+51+j];z[0]=input+C[0]*q0+C[1]*q1;z[1]=C[2]*q0+C[3]*q1;z[2]=input+C[4]*q0+C[5]*q1+C[6]*q2+C[7]*q3;z[3]=C[8]*q0+C[9]*q1+C[10]*q2+C[11]*q3;z[4]=input+C[12]*q0+C[13]*q1+C[14]*q2+C[15]*q3+C[16]*q4;}
      tick(){const raw=this.io[0];let input=raw;for(let section=0;section<2;section++){const at=section*5,st=section*2,C=this.preCoefficients,y=C[at]*input+this.pre[st];this.pre[st]=C[at+1]*input-C[at+3]*y+this.pre[st+1];this.pre[st+1]=C[at+2]*input-C[at+4]*y;input=y;}const analog=soft(input*(1+this.drive*1.5))/(1+this.drive*1.5),tri=this.mode==='I+II'?Math.sin(TAU*this.phase):1-4*Math.abs(this.phase-.5),clockL=this.baseClock*(1+this.depth*tri),clockR=this.baseClock*(1-this.depth*tri),incL=clockL*2/this.rate,incR=clockR*2/this.rate;
        const beforeL=this.clockL,beforeR=this.clockR;this.clockL+=incL;this.clockR+=incR;let n=0,last=0;this.postState=this.postL;
        while(this.clockL>=1&&n++<64){const time=(1-beforeL+(n-1))/incL;this.postHeld=this.heldL;this.postDelta=time-last;this._post();last=time;let x=this.noiseSeed;x^=x<<13;x^=x>>>17;x^=x<<5;this.noiseSeed=x>>>0;this.heldL=this.bucketL[this.indexL];this.bucketL[this.indexL]=(this.previous+(analog-this.previous)*time)*.992+(this.noiseSeed/2147483648-1)*this.noise*this.noise*.003;this.indexL=(this.indexL+1)&255;this.clockL--;}
        this.postHeld=this.heldL;this.postDelta=1-last;this._post();n=0;last=0;this.postState=this.postR;
        while(this.clockR>=1&&n++<64){const time=(1-beforeR+(n-1))/incR;this.postHeld=this.heldR;this.postDelta=time-last;this._post();last=time;let x=this.noiseSeed;x^=x<<13;x^=x>>>17;x^=x<<5;this.noiseSeed=x>>>0;this.heldR=this.bucketR[this.indexR];this.bucketR[this.indexR]=(this.previous+(analog-this.previous)*time)*.992+(this.noiseSeed/2147483648-1)*this.noise*this.noise*.003;this.indexR=(this.indexR+1)&255;this.clockR--;}
        this.postHeld=this.heldR;this.postDelta=1-last;this._post();this.previous=analog;const l=this.postL[4],r=this.postR[4];this.mix+=this.mixA*(this.target-this.mix);const middle=(l+r)*.5,side=(l-r)*.5*this.width;this.io[1]=this.io[0]+(middle+side)*this.mix*.8;this.io[2]=this.io[0]+(middle-side)*this.mix*.8;this.phase+=this.lfoHz/this.rate;if(this.phase>=1)this.phase-=1;this.clockHzL=clockL;this.clockHzR=clockR;
      }
      reset(){this.phase=this.clockL=this.clockR=this.indexL=this.indexR=this.previous=this.heldL=this.heldR=0;this.bucketL.fill(0);this.bucketR.fill(0);this.pre.fill(0);this.postL.fill(0);this.postR.fill(0);this.noiseSeed=0x4252494e;this.mix=this.target;this.io.fill(0);}
      getMeters(){return{mode:this.mode,stages:256,prefilterPoles:4,reconstructionPoles:5,transitionSteps:POST_STEPS,filterHz:this.filterHz,filterQ:this.filterQ,filterHz2:this.filterHz2,filterQ2:this.filterQ2,clockPoleHz:this.clockPoleHz,lfoHz:this.lfoHz,phase:this.phase,clockHzL:this.clockHzL||this.baseClock,clockHzR:this.clockHzR||this.baseClock,delayMsL:128000/(this.clockHzL||this.baseClock),delayMsR:128000/(this.clockHzR||this.baseClock)};}
    }
    class Core{
      constructor(rate=48000,state={},options={}){
        this.sampleRate=clamp(rate,8000,192000,48000);this.osr=this.sampleRate*OS;this.noiseScale=Math.sqrt(this.osr/96000);this.seed=(options.seed??state.seed??0x4252494e)>>>0||1;this.p=normalize(state);this.frame=0;this.serial=0;this.stolen=0;this.held=new Map();this.controllers={bend:[],wheel:[],sustain:[]};this.globalBend=0;this.globalWheel=this.p.modWheel;this.globalSustain=false;this.lfoPhase=hash(this.seed^0x4c464f)/4294967296;this.lfoDelayClock=0;this.manualDelayClock=0;this.manualActive=false;this.lfoManualGain=0;this.lfoGain=0;this.lfoValue=0;this.noiseSeed=hash(this.seed^0x4e4f4953)||1;this.white=0;this.hush=true;this.peak=this.rms=this.lastOutput=0;this.smooth=new Float64Array(14);this.targets=this.smooth.slice();this.smoothA=1-Math.exp(-1/(this.osr*.004));this.gateA=1-Math.exp(-1/(this.osr*.00264));this.dcA=Math.exp(-TAU*5/this.sampleRate);this.dcIn=new Float64Array(2);this.dcOut=new Float64Array(2);this.aaState=new Float64Array(16);this.aa=[];for(const q of [.5097955791,.6013448869,.8999762231,2.5629154477]){const w=TAU*this.sampleRate*.39/this.osr,c=Math.cos(w),a=Math.sin(w)/(2*q),a0=1+a;this.aa.push(new Float64Array([(1-c)*.5/a0,(1-c)/a0,(1-c)*.5/a0,-2*c/a0,(1-a)/a0]));}
        this.voices=Array.from({length:VOICE_COUNT},(_,index)=>({index,dco:new DCO(),filter:new Filter(this.osr),env:new Envelope(this.osr),active:false,gate:false,pitch:60,key:60,targetKey:60,hasNote:false,hz:261.6255653,owner:null,used:0,velocity:1,wheel:0,bend:0,gateGain:0,calWave:signed(this.seed+index*73+11),calPw:signed(this.seed+index*73+19),calFilter:signed(this.seed+index*73+31),calAmp:signed(this.seed+index*73+41),calEnv:signed(this.seed+index*73+59),pending:false,last:0,correction:0,correctionLeft:0}));
        this.hpf=new Highpass(this.osr);this.chorus=new Chorus(this.osr,this.p);this.maximumCutoff=Math.min(24000,this.sampleRate*.45);this.stealFrames=Math.max(1,Math.round(this.osr*.003));this.setState(state);this.reset();
      }
      setState(state={}){
        const before=this.p,p=normalize(state);this.p=p;if(!before||before.modWheel!==p.modWheel){if(this.globalWheel<=0&&p.modWheel>0)this.manualDelayClock=0;this.globalWheel=p.modWheel;this.manualActive=this.globalWheel>0||this.controllers.wheel.some(c=>c.value>0);}this.rangeFactor=p.range==='16'?.5:p.range==='4'?2:1;this.tuneFactor=exp2(p.masterTune/1200);this.lfoStep=p.lfoRate/this.osr;this.lfoDelayFrames=p.lfoDelay*this.osr;this.glideA=p.glide>0?1-Math.exp(-3/(p.glide*this.osr)):1;this.envSign=p.envPolarity==='negative'?-1:1;this.targets.set([p.saw?1:0,p.pulse?1:0,p.sub?p.subLevel:0,p.noiseLevel,Math.log2(p.cutoff),p.resonance,p.envAmount,p.filterLfo,p.dcoLfo,p.pwmAmount,p.ampLevel,p.volume,p.age,p.chorusDrive]);this.hpf.set(p.hpf,p.model);this.chorus.set(p);
        for(let i=0;i<VOICE_COUNT;i++){const v=this.voices[i],time=1+v.calEnv*p.age*.055;v.env.set({attack:p.envAttack*time,decay:p.envDecay*time,sustain:p.envSustain,release:p.envRelease*time,model:p.model});v.filterRatio=exp2(v.calFilter*p.age*.07);v.ampRatio=1+v.calAmp*p.age*.035;v.pwOffset=v.calPw*p.age*.004;this._refresh(v);if(before&&before.ampMode!==p.ampMode){if(p.ampMode==='env'&&v.env.stage)v.active=true;if(v.active)v.pending=true;}}
      }
      setPatch(patch={}){this.setState({...this.p,...(patch.synth||patch)});}
      _matches(entry,target){return(target.source===undefined||entry.source===target.source)&&(target.channel===undefined||entry.channel===target.channel)&&(target.id===undefined||entry.id===String(target.id))&&(target.pitch===undefined||entry.pitch===Math.round(target.pitch));}
      _control(kind,owner,fallback){let answer=fallback,priority=-1;const list=this.controllers[kind];for(let i=0;i<list.length;i++){const c=list[i];if(this._matches(owner,c)){const rank=(c.source===undefined?0:2)+(c.channel===undefined?0:1);if(rank>=priority){answer=c.value;priority=rank;}}}return answer;}
      _refresh(v){const owner=v.owner||{source:'',channel:0};v.bend=this._control('bend',owner,this.globalBend);v.wheel=this._control('wheel',owner,this.globalWheel);v.bendFactor=exp2(v.bend*this.p.bendRange/12);v.velocityGain=1-this.p.velocityAmount+this.p.velocityAmount*v.velocity;this._pitch(v);}
      _pitch(v){v.hz=440*exp2((v.key-69)/12);v.increment=v.hz*this.rangeFactor*this.tuneFactor*v.bendFactor/this.osr;v.tracking=(v.key-60)/12*this.p.keyTrack;}
      _allocate(entry){let best=null;for(let i=0;i<VOICE_COUNT;i++){const v=this.voices[i];if(!v.gate&&(!best||v.used<best.used))best=v;}if(best)return best;best=this.voices[0];for(let i=1;i<VOICE_COUNT;i++)if(this.voices[i].used<best.used)best=this.voices[i];return best;}
      _release(entry,immediate=false){this.held.delete(entry.key);for(let i=0;i<VOICE_COUNT;i++){const v=this.voices[i];if(v.owner===entry){v.gate=false;v.env.gate(false);if(immediate){v.active=false;v.env.reset();v.gateGain=0;v.filter.reset(1e-10);v.last=0;}}}}
      noteOn(event={}){const pitch=Math.round(clamp(event.pitch??event.note,0,127,60)),velocity=clamp(event.velocity,0,1,1);if(velocity===0){this.noteOff(event);return;}const source=String(event.source??'keyboard'),channel=Math.round(clamp(event.channel,0,15,0)),id=String(event.id??pitch),key=source+'\u0000'+channel+'\u0000'+id,had=this.held.size>0;
        for(const old of this.held.values())if(old.key===key||old.pitch===pitch&&old.source===source&&old.channel===channel)this._release(old);if(this.held.size>=256)this._release(this.held.values().next().value);const entry={id,key,pitch,velocity,source,channel,down:true,order:++this.serial};this.held.set(key,entry);const v=this._allocate(entry),old=v.owner;if(v.active&&old&&old.key!==key){if(v.gate&&!(old.pitch===pitch&&old.source===source&&old.channel===channel))this.stolen++;v.pending=true;}v.owner=entry;v.pitch=pitch;v.velocity=velocity;v.used=++this.serial;v.targetKey=pitch;if(!v.hasNote||this.glideA===1)v.key=pitch;v.hasNote=true;v.gate=v.active=true;v.env.gate(true);this._refresh(v);if(!had&&this.p.lfoTriggerMode==='auto')this.lfoDelayClock=0;this.hush=false;
      }
      _pedal(entry){return this.globalSustain||this._control('sustain',entry,false)===true;}
      noteOff(event={}){for(const e of this.held.values())if(this._matches(e,event)){e.down=false;if(!this._pedal(e))this._release(e);}}
      _setControl(kind,event,value){const oldWheel=kind==='wheel'?(event.source===undefined&&event.channel===undefined?this.globalWheel:this._control('wheel',{source:event.source??'',channel:event.channel??0},this.globalWheel)):0;if(event.source===undefined&&event.channel===undefined){if(kind==='bend')this.globalBend=value;else if(kind==='wheel')this.globalWheel=value;else this.globalSustain=value;}else{const list=this.controllers[kind];let found=list.find(c=>c.source===event.source&&c.channel===event.channel);if(!found){if(list.length>=256)list.shift();found={source:event.source,channel:event.channel,value};list.push(found);}else found.value=value;}if(kind==='wheel'){if(oldWheel<=0&&value>0)this.manualDelayClock=0;this.manualActive=this.globalWheel>0||this.controllers.wheel.some(c=>c.value>0);}if(kind==='sustain'){for(const e of this.held.values())if(!e.down&&!this._pedal(e))this._release(e);}else for(let i=0;i<VOICE_COUNT;i++)this._refresh(this.voices[i]);}
      sustain(event={}){this._setControl('sustain',event,event.down===true);}
      modWheel(event={}){this._setControl('wheel',event,clamp(event.value,0,1,0));}
      pitchBend(event={}){this._setControl('bend',event,clamp(event.value,-1,1,0));}
      cancelNotes(target={}){for(const e of this.held.values())if(this._matches(e,target))this._release(e,target.immediate===true);if(target.immediate===true)for(let i=0;i<VOICE_COUNT;i++){const v=this.voices[i];if(v.owner&&this._matches(v.owner,target)){v.active=v.gate=false;v.env.reset();v.gateGain=0;v.last=0;v.filter.reset(1e-10);}}}
      allNotesOff(){this.cancelNotes({});}
      panic(){this.held.clear();for(const list of Object.values(this.controllers))list.length=0;this.globalBend=0;this.globalWheel=this.p.modWheel;this.globalSustain=false;this.manualActive=this.globalWheel>0;this.manualDelayClock=0;this.lfoManualGain=0;this.hush=true;for(let i=0;i<VOICE_COUNT;i++){const v=this.voices[i];v.active=v.gate=v.pending=false;v.owner=null;v.env.reset();v.gateGain=v.last=v.correction=v.correctionLeft=0;v.filter.reset(1e-10);this._refresh(v);}this.hpf.reset();this.chorus.reset();this.aaState.fill(0);this.dcIn.fill(0);this.dcOut.fill(0);this.peak=this.rms=this.lastOutput=0;}
      reset(){this.frame=this.serial=this.stolen=0;this.lfoPhase=hash(this.seed^0x4c464f)/4294967296;this.lfoDelayClock=0;this.manualDelayClock=0;this.manualActive=false;this.lfoManualGain=0;this.lfoGain=0;this.noiseSeed=hash(this.seed^0x4e4f4953)||1;this.white=0;this.smooth.set(this.targets);this.panic();for(let i=0;i<VOICE_COUNT;i++){const v=this.voices[i];v.dco.reset(hash(this.seed+i*73+3)/2147483648);v.key=v.targetKey=v.pitch=60;v.used=0;v.hasNote=false;v.velocity=1;this._refresh(v);}}
      _decimate(input,channel){let out=input;const base=channel*8;for(let i=0;i<4;i++){const c=this.aa[i],at=base+i*2,y=c[0]*out+this.aaState[at];this.aaState[at]=c[1]*out-c[3]*y+this.aaState[at+1];this.aaState[at+1]=c[2]*out-c[4]*y;out=y;}return out;}
      process(left,right){if(!left||!right||left.length!==right.length)throw Error('BRINE requires equal stereo blocks.');const p=this.p,s=this.smooth,t=this.targets;let peak=0,power=0;for(let frame=0;frame<left.length;frame++,this.frame++){let outL=0,outR=0;for(let sub=0;sub<OS;sub++){
            for(let j=0;j<s.length;j++)s[j]+=this.smoothA*(t[j]-s[j]);let x=this.noiseSeed;x^=x<<13;x^=x>>>17;x^=x<<5;this.noiseSeed=x>>>0;this.white=(this.noiseSeed/2147483648)-1;this.lfoValue=1-4*Math.abs(this.lfoPhase-.5);this.lfoPhase+=this.lfoStep;if(this.lfoPhase>=1)this.lfoPhase-=1;const delayed=this.lfoDelayFrames===0?1:Math.min(1,this.lfoDelayClock/this.lfoDelayFrames);this.lfoGain=delayed*delayed*(3-2*delayed);if(this.lfoDelayClock<this.lfoDelayFrames)this.lfoDelayClock++;const manualPosition=this.lfoDelayFrames===0?1:Math.min(1,this.manualDelayClock/this.lfoDelayFrames);this.lfoManualGain=this.manualActive?manualPosition*manualPosition*(3-2*manualPosition):0;if(this.manualActive&&this.manualDelayClock<this.lfoDelayFrames)this.manualDelayClock++;
            let sum=0;for(let index=0;index<VOICE_COUNT;index++){const v=this.voices[index];if(v.key!==v.targetKey){v.key+=this.glideA*(v.targetKey-v.key);if(Math.abs(v.key-v.targetKey)<1e-8)v.key=v.targetKey;this._pitch(v);}const depth=p.lfoTriggerMode==='manual'?v.wheel*this.lfoManualGain:Math.max(this.lfoGain,v.wheel*this.lfoManualGain),mod=this.lfoValue*depth,increment=Math.min(.4,v.increment*(s[8]===0||mod===0?1:exp2(s[8]*mod*.5)));if(!v.active){if(v.env.stage)v.env.tick();v.dco.phase+=increment;if(v.dco.phase>=2)v.dco.phase-=2;v.dco.lastWidth=clamp(.5+s[9]*.45*(p.pwmSource==='manual'?1:p.pwmSource==='env'?v.env.value:this.lfoValue)+v.pwOffset,.05,.95,.5);continue;}v.env.tick();const env=v.env.value;v.gateGain+=this.gateA*((v.gate?1:0)-v.gateGain);const width=clamp(.5+s[9]*.45*(p.pwmSource==='manual'?1:p.pwmSource==='env'?env:this.lfoValue)+v.pwOffset,.05,.95,.5),io=v.dco.io;io[0]=increment;io[1]=width;v.dco.tick();const saw=io[2]+v.calWave*s[12]*.007*(1-io[2]*io[2]),mix=(saw*s[0]+io[3]*s[1]+io[4]*s[2]+this.white*s[3]*this.noiseScale)*.33;
              const cutoff=Math.max(5,Math.min(this.maximumCutoff,exp2(s[4]+v.tracking+env*s[6]*8*this.envSign+mod*s[7]*3+v.bend*p.bendFilter*2)*v.filterRatio)),f=v.filter.io;f[0]=mix;f[1]=cutoff;f[2]=s[5];v.filter.tick();const amp=p.ampMode==='gate'?v.gateGain:env;let value=f[3]*amp*v.velocityGain*v.ampRatio;if(v.pending){v.pending=false;v.correction=v.last-value;v.correctionLeft=this.stealFrames;}if(v.correctionLeft>0)value+=v.correction*v.correctionLeft--/this.stealFrames;v.last=value;sum+=value;if(v.correctionLeft===0&&(p.ampMode==='gate'?v.gateGain<1e-7&&!v.gate:!v.env.stage)){v.active=false;v.last=0;v.dco.sawCarry=v.dco.pulseCarry=v.dco.subCarry=0;}}
            const high=this.hpf.process(sum*.15),gain=s[10]*2,analog=soft(high*gain/.85)*.85,cio=this.chorus.io;cio[0]=this.hush?0:analog;const noise=this.chorus.noise;if(this.hush)this.chorus.noise=0;this.chorus.tick();this.chorus.noise=noise;outL=this._decimate(cio[1]*s[11],0);outR=this._decimate(cio[2]*s[11],1);
          }
          if((this.frame&255)===0){for(let j=0;j<this.aaState.length;j++)if(Math.abs(this.aaState[j])<1e-24)this.aaState[j]=0;for(let v=0;v<VOICE_COUNT;v++)for(let j=0;j<4;j++)if(Math.abs(this.voices[v].filter.z[j])<1e-24)this.voices[v].filter.z[j]=0;}
          const l=outL-this.dcIn[0]+this.dcA*this.dcOut[0],r=outR-this.dcIn[1]+this.dcA*this.dcOut[1];this.dcIn[0]=outL;this.dcIn[1]=outR;this.dcOut[0]=Math.abs(l)<1e-25?0:l;this.dcOut[1]=Math.abs(r)<1e-25?0:r;left[frame]=this.hush?0:this.dcOut[0];right[frame]=this.hush?0:this.dcOut[1];peak=Math.max(peak,Math.abs(left[frame]),Math.abs(right[frame]));power+=left[frame]*left[frame]+right[frame]*right[frame];this.lastOutput=left[frame];
        }this.peak=peak;this.rms=Math.sqrt(power/Math.max(1,left.length*2));}
      getMeters(){return{voices:this.voices.reduce((n,v)=>n+(v.active?1:0),0),voiceLimit:VOICE_COUNT,voiceStates:this.voices.map(v=>({index:v.index,pitch:v.pitch,active:v.active,gate:v.gate,level:v.env.value,env:v.env.value,phase:v.dco.phase,subPhase:v.dco.phase*.5})),peak:this.peak,rms:this.rms,stolen:this.stolen,frame:this.frame,lfo:this.lfoValue,lfoPhase:this.lfoPhase,lfoGain:this.lfoGain,lfoManualGain:this.lfoManualGain,noise:this.white,oversampling:OS,chorus:this.chorus.getMeters()};}
      getTailTime(){return estimateTail(this.p);}
    }

    return {Core,defaults:Object.freeze({...defaults}),specifications,normalize,estimateTail,Envelope,DCO,Filter,Highpass,Chorus,oversampling:OS,voiceCount:VOICE_COUNT};
  }
  scope.createBrineDSP=createBrineDSP;
})(typeof window==='undefined'?globalThis:window);
