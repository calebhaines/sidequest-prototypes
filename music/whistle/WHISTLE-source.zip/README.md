# WHISTLE

A loop, not a sample. WHISTLE is a self-oscillating feedback and distortion
unit for Kitchen, numbered **K—15** on the equipment list.

Noise is pushed through a waveshaper burner, damped at the vent, then returned
through a tuned spout delay until the loop finds its own note. Nothing is
pre-rendered: every sound it makes is generated live in the Web Audio graph.

## Files

- `index.html` — the whole instrument: markup, styles and engine in one
  self-contained file, with the Kilter Condensed face embedded. No external
  assets, no runtime dependencies, no samples.
- `README.md` — this file.

The published copy lives at `music/whistle/index.html`; `npm run music:sync`
copies it into `public/music/` and `docs/music/`. This instrument has no
`build.py` stage because the single file is already the build output.

## Signal path

```
noise ──► burner (waveshaper) ──► vent (bandpass) ──► kettle (master) ──► limiter ──► out
                    ▲                   │
                    │                   ▼
                pressure ◄──── spout delay ◄──── damping (lowpass)
```

The loop is legal in Web Audio because the cycle contains a `DelayNode`.
Feedback is capped at 0.92 and the output passes a `DynamicsCompressor` before
the destination so a runaway setting cannot reach full scale.

## Controls

| Control | What it does |
| --- | --- |
| **BURNER** | Drive into the waveshaper, 1× to 25×. Adds harmonics, then fold. |
| **PRESSURE** | Loop feedback, 0–92%. Above roughly 70% it self-oscillates. |
| **SPOUT** | Loop period, 2–90 ms. Retunes the live loop while a pitch is held. |
| **VENT** | Loop damping, 280 Hz to 8 kHz. Lower is darker and more stable. |
| **GLASS** | Bandpass resonance, Q 0.7–22.7. |
| **KETTLE** | Output level. |

Eight pitch pads (110–293.66 Hz) set the loop period so the kettle whistles at
that note. **SHRIEK** momentarily raises pressure and excites the loop;
**HOLD** keeps the last pitch latched; **VENT** ramps feedback to zero and
lets the loop settle.

Keyboard: `A S D F G H J K` play the pads, `Space` shrieks. Knobs respond to
pointer drag and to arrow keys when focused.


## Sequencer

A 32-step recipe under the instrument. Each step carries its own note and an
optional lock for any of the six dials, so a step can ask for a pressure or a
vent setting that the dials are not currently set to.

- **Length** — 16 or 32. The grid keeps sixteen visible positions; the page
  buttons switch between `1–16` and `17–32`. Pages do not follow the playhead,
  the same as the other Kitchen sequencers.
- **Dial lane** — choose `NOTE` or one of the six dials. Dragging a step upward
  writes that lane's value for that step; the cell shows the value over a
  vertical bar. Right-click clears the lane on that step.
- **Step inspector** — selects the current step, toggles it on or off, sets its
  note, and lists every dial with a slider plus a clear button. A row reads
  `dial` when unlocked, so only deviations are stored.
- **Rate / Tempo** — `1/8`, `1/16` or `1/32` at 40–200 bpm. `P` or the Play
  button runs the transport.

Unlocked dials track the live knob position, so moving a knob while the recipe
runs still changes the sound on every step that has not locked that dial.
Stopping the transport restores the knob values.

## Notes

- Audio starts on the first pointer or key gesture, as browsers require.
- The scope reads an `AnalyserNode`; it draws an idle line until the loop runs.
- Respects `prefers-reduced-motion` by disabling transitions.
