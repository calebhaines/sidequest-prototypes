# Grease Trap — texture ingredients

Eight original supporting textures, printed through the current native Kitchen
instruments in a browser. Every WAV is **106 BPM, four bars / 16 beats, 48 kHz
stereo, 434,717 frames**, with no appended tail. No external recordings, borrowed
melodies, lyrics, or surrogate synthesizers are used.

| GALLEY role | Ingredient | Suggested use |
| --- | --- | --- |
| Piston / metal punctuation | `reduce-piston.wav` | Verse: two low-mid piston pulses, offbeat latch replies, one small ceramic accent per bar. |
| Piston / metal punctuation | `reduce-clamp.wav` | Chorus: additional latch replies and a more insistent nonlinear spring. |
| Piston / metal punctuation | `reduce-last-call.wav` | Final escalation or phrase ending: longer D5 plate, tiny three-strike friction accent. |
| Vowel ghost / pad | `marinade-mouth.wav` | Sparse D4/A4/F4/C4 gestures; a human-shaped, wordless reply to the mechanical hook. |
| Vowel ghost / pad | `marinade-ghost.wav` | Breakdown: slower D4/F4/C5/A4 whispered reconstruction and shifting formants. |
| Disturbed room / tape noise | `steam-room.wav` | Intro, exposed gaps, and a restrained breakdown bed. Breathing ventilation over D harmonics. |
| Disturbed room / tape noise | `steam-pressure.wav` | A four-bar rise into a chorus or final section; use selectively. |
| Disturbed room / tape noise | `rotisserie-intake.wav` | Reversed, slowed REDUCE punctuation through native tape wear/wow/flutter; thin suction in empty spaces. |

The quiet voices are intentional: this layer should leave room for the main
drums, bass and hook. MARINADE can take roughly 6–12 dB of clip gain in an exposed
breakdown; STEAM can take 3–6 dB. REDUCE has low-mid body, so high-pass its GALLEY
track around 160–250 Hz if the bass needs more space.

Use GALLEY's 10–25 ms fade-out on the two STEAM clips: its native zero-tail export
can end on a small nonzero sample. The other exports already end at zero. These
are end fades inside the existing phrase, not extra audio beyond four bars.

`manifest.json` records dimensions, levels, roles, and portable patch paths.
`audio-qa.json` records finite samples, DC, mono compatibility and spectral power.
`render.cjs` reproduces the native browser exports and snapshots. The ROTISSERIE
project contains its original REDUCE audio source, so it is self-contained.
