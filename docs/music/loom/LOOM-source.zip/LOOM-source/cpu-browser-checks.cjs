'use strict';
// Actual Chromium CPU inspector, coarse Worklet clock, profiler lifecycle and audio parity.
// LOOM_CPU_QA_BUILT=1 selects the published standalone. Otherwise use maintained
// sources without loading the large bundled instruments. Phases: engine,ui.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const { execFileSync } = require('node:child_process');
const { chromium } = require(process.env.PLAYWRIGHT_MODULE || '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const root = path.resolve(__dirname, '..'), shared = fs.existsSync(path.join(__dirname, 'shared/pattern-schema.js')) ? path.join(__dirname, 'shared') : path.join(root, 'shared');
const artifacts = process.env.LOOM_CPU_QA_DIR || '/tmp/galley-cpu-browser-qa', evidence = {}, passed = [];
const scripts = ['vocal-catalog.js', 'utility-catalog.js', 'filter-catalog.js', 'creative-catalog.js', 'preamp-catalog.js', 'tape-catalog.js', 'char-catalog.js', 'lofi-catalog.js','pedal-synth-catalog.js', 'deluxe-catalog.js', 'effects-catalog.js', 'vocal-dsp.js', 'utility-dsp.js', 'filter-dsp.js', 'creative-dsp.js', 'broiler-pedals.js', 'compressor-dsp.js', 'preamp-dsp.js', 'tape-dsp.js', 'char-dsp.js', 'lofi-dsp.js','pedal-synth-tracker.js','pedal-synth-dsp.js', 'deluxe-dsp.js', 'effects.js', 'lfo.js', 'cpu-profiler.js', 'track-eq-dsp.js', 'service-schema.js', 'schema.js', 'audio-engine.js'];
function maintainedHTML() {
  if (process.env.LOOM_CPU_QA_BUILT) return fs.readFileSync(path.join(__dirname, 'index.html'));
  const python = `from pathlib import Path
import ast,base64,re,runpy,sys
p=Path(sys.argv[1]); shared=Path(sys.argv[2]); source=(p/'build.py').read_text(); tree=ast.parse(source)
names=next(ast.literal_eval(node.value) for node in tree.body if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SCRIPTS' for t in node.targets))
css='\\n'.join((p/name).read_text() for name in dict.fromkeys(re.findall(r"ROOT / '([^']+\\.css)'",source)))
fonts=[]
for family,weight,style,name in [('Loom Sans',400,'normal','noto-sans-regular.woff2'),('Loom Sans',700,'normal','noto-sans-bold.woff2'),('Loom Serif',400,'normal','noto-serif-regular.woff2'),('Loom Serif',400,'italic','noto-serif-italic.woff2')]:
 data=base64.b64encode((p/'fonts'/name).read_bytes()).decode(); fonts.append('@font-face{font-family:'+repr(family)+';font-style:'+style+';font-weight:'+str(weight)+';src:url(data:font/woff2;base64,'+data+") format('woff2')}")
css=css.replace('/* FONT_FACES */','\\n'.join(fonts))
code='window.LoomEmbeddedInstruments={};window.LoomDemoAssets={};window.LoomDemoTemplate=null;\\n'+'\\n'.join((p/name).read_text() for name in names)
html=(p/'app.html').read_text().replace('<!-- STYLES -->','<style>'+css+'</style>').replace('<!-- SCRIPTS -->','<script>'+code.replace('</script','<\\\\/script')+'</script>')
helpers=runpy.run_path(str(shared/'bundle_audio_exchange.py'));sys.stdout.write(helpers['embed_exchange'](html,'loom',p))`;
  return execFileSync('python3', ['-c', python, __dirname, shared], { maxBuffer: 36 * 1024 * 1024 });
}
async function serve() {
  let ui;
  const server = http.createServer((req, res) => {
    const pathname = new URL(req.url, 'http://local').pathname;
    if (pathname === '/favicon.ico') { res.writeHead(204); res.end(); return; }
    if (pathname === '/loom/index.html' || pathname === '/engine.html' && process.env.LOOM_CPU_QA_BUILT) { ui ||= maintainedHTML(); res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); res.end(ui); return; }
    if (pathname === '/engine.html') { res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); res.end('<!doctype html><body><script src="/shared/pattern-schema.js"></script>' + scripts.map(file => '<script src="/loom/' + file + '"></script>').join('')); return; }
    const base = pathname.startsWith('/loom/') ? __dirname : pathname.startsWith('/shared/') ? shared : root, relative = pathname.startsWith('/loom/') ? pathname.slice(5) : pathname.startsWith('/shared/') ? pathname.slice(7) : pathname;
    const file = path.resolve(base, '.' + relative); if (!file.startsWith(base + path.sep)) { res.writeHead(403); res.end(); return; }
    fs.readFile(file, (error, bytes) => { res.writeHead(error ? 404 : 200, { 'Content-Type': file.endsWith('.js') ? 'text/javascript' : 'application/octet-stream' }); res.end(error ? 'Missing fixture' : bytes); });
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve)); return { url: 'http://127.0.0.1:' + server.address().port, close: () => new Promise(resolve => server.close(resolve)) };
}
async function helpers(page) {
  await page.evaluate(() => {
    window.cpuQA = {
      messages: [],
      blank() { const state = LoomSchema.defaultState(); state.name = 'CPU_QA_PRIVATE_PROJECT'; state.tempo = 120; state.lengthBars = 8; state.loopEnabled = true; state.loopEnd = 32; state.recording.punchEnd = 32; for (const owner of [...state.tracks, ...state.returns, state.master]) { owner.level = .7; owner.effects.fill(null); owner.automation = []; } state.tracks.forEach(track => track.instrumentLive = true); return state; },
      fixture() { const state = this.blank(); state.tracks[0].effects[0] = LoomSchema.effect({ type: 'prism', params: { filter: 'lowpass', cutoff: 1900, mix: .8 } }); state.tracks[0].effects[1] = LoomSchema.effect({ type: 'preserve', params: { drive: 9, warmth: .6, mix: .7 } }); state.tracks[0].effects[4] = LoomSchema.effect({ type: 'cinder', params: { drive: 5, output: -5, mix: .2 } }); state.tracks[0].eq = { ...LoomSchema.defaultTrackEq(), low: 1, lowMid: 0, highMid: -.5, high: 2, lowMidFreq: 650, highMidFreq: 4100 }; state.tracks[0].sends = [.2, .1]; state.returns[0].effects[2] = LoomSchema.effect({ type: 'cinder', params: { drive: 6, mix: .4 } }); state.master.effects[3] = LoomSchema.effect({ type: 'prism', params: { filter: 'highpass', cutoff: 50, mix: 1 } }); return state; },
      source(frames = 8192, rate = 48000) { return [0, 1].map(channel => Float32Array.from({ length: frames }, (_, index) => .08 * Math.sin(2 * Math.PI * (channel ? 227 : 137) * index / rate) + .02 * Math.sin(2 * Math.PI * (channel ? 1327 : 1703) * index / rate))); },
      difference(a, b) { let max = 0; for (let index = 0; index < a.length; index++) { if (!Number.isFinite(a[index]) || !Number.isFinite(b[index])) throw Error('Non-finite audio'); max = Math.max(max, Math.abs(a[index] - b[index])); } return max; },
      watchCallbackHooks: function (core, recorder) {
        const hooks = ['begin', 'start', 'end', 'finish', 'runtimeBegin', 'runtimeStart', 'runtimeEnd', 'runtimeFinish'];
        const counters = { off: Object.fromEntries(hooks.map(key => [key, 0])), on: Object.fromEntries(hooks.map(key => [key, 0])), operations: { off: { blocks: 0, captures: 0, meters: 0 }, on: { blocks: 0, captures: 0, meters: 0 } } }, seen = new WeakSet();
        const phase = () => core.cpuProfiler?.enabled === true ? 'on' : 'off';
        const wrap = (object, method, key, normal = false) => {
          const original = object[method]; if (typeof original !== 'function') throw Error('Missing callback hook ' + method);
          object[method] = function (...args) { (normal ? counters.operations[phase()] : counters[phase()])[key]++; return original.apply(this, args); };
        };
        for (const [method, key] of [['beginDiagnostics', 'begin'], ['diagnosticsStart', 'start'], ['diagnosticsEnd', 'end'], ['endDiagnostics', 'finish']]) wrap(core, method, key);
        wrap(core, 'processBlock', 'blocks', true); wrap(core, 'getMeters', 'meters', true); wrap(recorder, 'capture', 'captures', true);
        const watchRuntime = () => {
          const runtime = core.cpuProfiler; if (!runtime || seen.has(runtime)) return; seen.add(runtime);
          for (const [method, key] of [['begin', 'runtimeBegin'], ['start', 'runtimeStart'], ['endStage', 'runtimeEnd'], ['finish', 'runtimeFinish']]) wrap(runtime, method, key);
        };
        const configure = core.setDiagnostics;
        core.setDiagnostics = function (...args) { const result = configure.apply(this, args); watchRuntime(); return result; };
        watchRuntime(); return counters;
      },
      observe(engine) { const previous = engine._message.bind(engine); engine._message = message => { if (message.type === 'diagnostics') this.messages.push({ revision: message.report?.revision, generation: message.generation }); return previous(message); }; },
      startTone(engine) { const oscillator = engine.context.createOscillator(), gain = engine.context.createGain(); oscillator.frequency.value = 137; gain.gain.value = .12; oscillator.connect(gain); gain.connect(engine.getTrackInput('track-1')); oscillator.start(); this.oscillator = oscillator; },
      core(state, frames = 8192, block = 137) { const core = new (createLoomEngineDSP(createLoomEffectsDSP, createLoomLFODSP, createLoomCPUProfiler, window.createLoomTrackEQDSP).Core)(state, {}, 48000, { linear: true }), input = this.source(frames), output = [new Float32Array(frames), new Float32Array(frames)]; core.start(0); for (let at = 0; at < frames; at += block) core.processBlock(output[0].subarray(at, at + block), output[1].subarray(at, at + block), [[input[0].subarray(at, at + block), input[1].subarray(at, at + block)]]); return { core, input, output }; }
    };
  });
}
async function engineChecks(browser, url) {
  const page = await browser.newPage(), errors = []; page.on('pageerror', error => errors.push(error.message));
  try {
    await page.goto(url + '/engine.html'); await helpers(page);
    const serialized = await page.evaluate(async () => {
      const q = cpuQA, state = q.fixture(), nativeURL = URL.createObjectURL, NativeNode = AudioWorkletNode; let blob, processorOptions;
      URL.createObjectURL = value => { if (value.type.includes('javascript')) blob = value; return nativeURL.call(URL, value); };
      window.AudioWorkletNode = class extends NativeNode { constructor(...args) { super(...args); processorOptions = args[2].processorOptions; } };
      const engine = q.engine = new LoomAudio(state); await engine.applyAudioSettings({ sampleRate: 48000, latencyProfile: 'live' }); await engine.init(); URL.createObjectURL = nativeURL; window.AudioWorkletNode = NativeNode;
      if (engine.mode !== 'worklet') throw Error('AudioWorklet initialization failed: ' + engine.workletError);
      const code = await blob.text(), frames = 8192, reference = q.core(state, frames), observations = [];
      for (const scenario of ['off', 'on', 'on-off']) {
        const enabled = scenario === 'on', initiallyEnabled = scenario !== 'off', toggleAt = scenario === 'on-off' ? frames / 2 : -1;
        const observer = '\nconst watchCPUCallbackHooks=(' + q.watchCallbackHooks.toString() + ');\nregisterProcessor("cpu-qa-offline",class extends LoomProcessor { constructor(options){super(options);this.qaHooks=watchCPUCallbackHooks(this.core,this.recorder);this.core.start(0);this.core.setDiagnostics({enabled:' + initiallyEnabled + ',mode:"deep"});this.qaFrames=0;this.qaOffTimerReads=null;} process(inputs,outputs){const result=super.process(inputs,outputs);this.qaFrames+=outputs[0][0].length;if(this.qaFrames===' + toggleAt + ')this.qaOffTimerReads=this.core.setDiagnostics({enabled:false}).timerReads;if(this.qaFrames===' + frames + ')this.port.postMessage({type:"cpu-qa-final",snapshot:this.core.getDiagnostics(),hooks:this.qaHooks,offTimerReads:this.qaOffTimerReads,microphoneClock:this.recorder.microphoneClock});return result;} });';
        const offline = new OfflineAudioContext(2, frames, 48000), module = nativeURL.call(URL, new Blob([code + observer], { type: 'text/javascript' }));
        try { await offline.audioWorklet.addModule(module); } finally { URL.revokeObjectURL(module); }
        const node = new NativeNode(offline, 'cpu-qa-offline', { numberOfInputs: 9, numberOfOutputs: 1, outputChannelCount: [2], channelCount: 2, channelCountMode: 'explicit', processorOptions }); let result;
        const final = new Promise((resolve, reject) => { const timer = setTimeout(() => reject(Error('Offline diagnostic snapshot timeout')), 10000); node.port.onmessage = event => { if (event.data.type === 'cpu-qa-final') { clearTimeout(timer); result = event.data; resolve(); } }; });
        const input = q.source(frames), buffer = offline.createBuffer(2, frames, 48000); buffer.copyToChannel(input[0], 0); buffer.copyToChannel(input[1], 1); const source = offline.createBufferSource(); source.buffer = buffer; source.connect(node, 0, 0); node.connect(offline.destination); source.start(0);
        const rendered = await offline.startRendering(); await final; observations.push({ scenario, enabled, leftError: q.difference(rendered.getChannelData(0), reference.output[0]), rightError: q.difference(rendered.getChannelData(1), reference.output[1]), ...result });
      }
      q.observe(engine); q.startTone(engine); engine.setDiagnostics({ enabled: true, mode: 'deep' }); await engine.play(0); return { serializedFactory: code.includes('createLoomCPUProfiler'), observations };
    });
    assert(serialized.serializedFactory); for (const observation of serialized.observations) {
      assert.equal(observation.leftError, 0); assert.equal(observation.rightError, 0); assert.equal(observation.snapshot.enabled, observation.enabled);
      assert(Object.values(observation.hooks.off).every(count => count === 0), observation.scenario + ': OFF production Worklet must not enter any profiling helper');
      const operations = observation.hooks.operations; assert.equal(operations.off.blocks + operations.on.blocks, 64); assert.equal(operations.off.captures + operations.on.captures, 64); assert.equal(operations.off.meters + operations.on.meters, 8); assert.equal(observation.microphoneClock, 8192, 'Normal recorder history advances in every profiling mode');
      if (observation.scenario !== 'off') { assert(Object.values(observation.hooks.on).every(count => count > 0), 'ON Worklet must exercise the real Core and Runtime profiling helpers'); assert(observation.snapshot.sampledBlocks > 0); assert(observation.snapshot.rows.some(row => row.effectType === 'preserve' && row.samples > 0)); assert.equal(observation.snapshot.clock.coarse, true); assert.equal(observation.snapshot.clock.name, 'Date.now'); }
      else assert.equal(observation.snapshot.timerReads, 0);
      if (observation.scenario === 'on-off') { assert.equal(operations.on.blocks, 32); assert.equal(operations.off.blocks, 32); assert.equal(observation.snapshot.timerReads, observation.offTimerReads, 'Clocks stay stopped after profiling is disabled'); }
    }
    await page.waitForFunction(() => cpuQA.engine.getDiagnostics().sampledBlocks >= 16 && cpuQA.engine.getMeters().master.rms > .001, null, { timeout: 15000 });
    const live = await page.evaluate(() => cpuQA.engine.getDiagnostics()); assert(live.rows.some(row => row.ownerId === 'master' && row.slot === 3 && row.samples > 0)); assert(live.rows.some(row => row.ownerId === 'return-1' && row.slot === 2 && row.samples > 0)); assert(live.rows.some(row => row.ownerId === 'track-1' && row.slot === 0 && row.samples > 0)); assert(live.rows.some(row => row.ownerId === 'track-1' && row.slot === 4 && row.samples > 0 && row.calls > 0)); assert.equal(live.rows.length, 89); assert(!live.rows.some(row => row.kind === 'effect' && !row.ownerId.startsWith('track-') && row.slot === 4));
    const off = await page.evaluate(async () => { cpuQA.engine.setDiagnostics({ enabled: false }); await new Promise(resolve => setTimeout(resolve, 600)); const before = { messages: cpuQA.messages.length, reads: cpuQA.engine.getDiagnostics().timerReads }; await new Promise(resolve => setTimeout(resolve, 600)); return { before, after: { messages: cpuQA.messages.length, reads: cpuQA.engine.getDiagnostics().timerReads }, enabled: cpuQA.engine.getDiagnostics().enabled, audible: cpuQA.engine.getMeters().master.rms }; });
    assert.equal(off.enabled, false); assert.deepEqual(off.after, off.before, 'Disabled real Worklet produces no periodic profiler traffic or clock reads.'); assert(off.audible > .001);
    await page.evaluate(async () => { await cpuQA.engine.dispose(); const saved = window.AudioWorkletNode; window.AudioWorkletNode = undefined; const engine = cpuQA.engine = new LoomAudio(cpuQA.fixture()); try { await engine.applyAudioSettings({ sampleRate: 48000, latencyProfile: 'live' }); await engine.init(); } finally { window.AudioWorkletNode = saved; } cpuQA.messages = []; cpuQA.fallbackHooks = cpuQA.watchCallbackHooks(engine.core, engine.recorder); cpuQA.observe(engine); cpuQA.startTone(engine); await engine.play(0); });
    await page.waitForFunction(() => cpuQA.fallbackHooks.operations.off.blocks >= 4 && cpuQA.engine.getMeters().master.rms > .001, null, { timeout: 15000 });
    const fallbackInitial = await page.evaluate(() => ({ hooks: JSON.parse(JSON.stringify(cpuQA.fallbackHooks)), enabled: cpuQA.engine.getDiagnostics().enabled })); assert.equal(fallbackInitial.enabled, false); assert(Object.values(fallbackInitial.hooks.off).every(count => count === 0), 'OFF fallback must not enter profiling helpers');
    await page.evaluate(() => cpuQA.engine.setDiagnostics({ enabled: true, mode: 'balanced' }));
    await page.waitForFunction(() => cpuQA.engine.getDiagnostics().sampledBlocks >= 4 && cpuQA.engine.getMeters().master.rms > .001, null, { timeout: 15000 }); const fallback = await page.evaluate(() => ({ mode: cpuQA.engine.mode, report: cpuQA.engine.getDiagnostics() })); assert.equal(fallback.mode, 'fallback'); assert.equal(fallback.report.clock.name, 'performance.now'); assert.equal(fallback.report.clock.coarse, false); assert(fallback.report.rows.some(row => row.effectType === 'preserve' && row.samples > 0));
    await page.evaluate(() => cpuQA.engine.resetDiagnostics()); await page.waitForFunction(() => cpuQA.engine.getDiagnostics().sampledBlocks > 0); const reset = await page.evaluate(() => cpuQA.engine.getDiagnostics()); assert(reset.sampledBlocks < fallback.report.sampledBlocks + 10, 'Reset starts a new sample window.');
    const fallbackDisable = await page.evaluate(() => { cpuQA.engine.setDiagnostics({ enabled: false }); return { blocks: cpuQA.fallbackHooks.operations.off.blocks, reads: cpuQA.engine.getDiagnostics().timerReads }; });
    await page.waitForFunction(blocks => cpuQA.fallbackHooks.operations.off.blocks >= blocks + 4, fallbackDisable.blocks);
    const fallbackOff = await page.evaluate(() => ({ hooks: cpuQA.fallbackHooks, reads: cpuQA.engine.getDiagnostics().timerReads, audible: cpuQA.engine.getMeters().master.rms }));
    assert(Object.values(fallbackOff.hooks.off).every(count => count === 0), 'Fallback must stay outside every profiling helper after ON → OFF'); assert(Object.values(fallbackOff.hooks.on).every(count => count > 0), 'ON fallback must exercise the real profiling helpers'); assert.equal(fallbackOff.reads, fallbackDisable.reads); assert(fallbackOff.audible > .001); for (const phase of ['off', 'on']) assert.equal(fallbackOff.hooks.operations[phase].captures, fallbackOff.hooks.operations[phase].blocks, 'Fallback capture continues once per normal callback'); assert(fallbackOff.hooks.operations.off.meters > 0);
    assert.deepEqual(errors, []); evidence.engine = { serialized: { factory: serialized.serializedFactory, observations: serialized.observations.map(observation => ({ scenario: observation.scenario, enabled: observation.enabled, leftError: observation.leftError, rightError: observation.rightError, clock: observation.snapshot.clock, timerReads: observation.snapshot.timerReads, sampledBlocks: observation.snapshot.sampledBlocks, hooks: observation.hooks, offTimerReads: observation.offTimerReads })) }, live, off, fallback, fallbackInitial, fallbackOff, reset };
  } finally { await page.evaluate(() => cpuQA?.engine?.dispose()).catch(() => {}); await page.close(); }
}
async function uiChecks(browser, url) {
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, reducedMotion: 'reduce', acceptDownloads: true }), page = await context.newPage(), errors = [], requests = [];
  page.on('pageerror', error => errors.push(error.message)); await context.route('**/*', route => { if (route.request().url() === url + '/loom/index.html') return route.continue(); requests.push(route.request().url()); return route.abort(); });
  try {
    await page.goto(url + '/loom/index.html'); await page.waitForFunction(() => window.LoomApp?.cpuInspector); await helpers(page); await page.evaluate(() => LoomApp.loadState(cpuQA.fixture()));
    const hatch = page.locator('#cpuInspector'), summary = page.locator('#cpuInspector > summary'); assert.equal(await hatch.evaluate(element => element.open), false); const closed = await page.evaluate(() => ({ enabled: LoomApp.engine.getDiagnostics().enabled, interval: LoomApp.cpuInspector.interval, frame: LoomApp.cpuInspector.frame, observer: !!LoomApp.cpuInspector.observer, mode: LoomApp.engine.mode })); assert.equal(closed.enabled, false); assert.equal(closed.interval, 0); assert.equal(closed.frame, 0); assert.equal(closed.observer, false); assert.equal(closed.mode, 'idle');
    await summary.focus(); await summary.press('Enter'); await page.waitForFunction(() => LoomApp.cpuInspector.active); assert.equal(await page.evaluate(() => LoomApp.engine.mode), 'idle', 'Opening diagnostics does not start an audio context.');
    await page.evaluate(async () => { await LoomApp.engine.init(); cpuQA.engine = LoomApp.engine; cpuQA.startTone(LoomApp.engine); await LoomApp.engine.play(0); }); await page.waitForFunction(() => LoomApp.engine.getDiagnostics().sampledBlocks >= 4, null, { timeout: 15000 });
    assert.equal(await page.locator('[data-cpu-owner]').count(), 13); await page.locator('[data-cpu-owner="track-1"] > summary').click(); assert.equal(await page.locator('[data-cpu-owner="track-1"] [data-cpu-row]').count(), 7); assert.equal(await page.locator('[data-cpu-owner="return-1"] [data-cpu-row]').count(), 5); assert.equal(await page.locator('[data-cpu-owner="master"] [data-cpu-row]').count(), 6); assert.equal(await page.locator('[data-cpu-owner="track-1"] [data-cpu-row="track-1:fx:4"]').count(), 1); await page.waitForFunction(() => document.querySelector('[data-cpu-row="track-1:fx:0"] [data-cpu-stat="samples"]').textContent !== '—');
    assert.match(await page.locator('[data-cpu-message]').innerText(), /coarse|at least|estimate|millisecond/i); const stateBefore = await page.evaluate(() => LoomApp.getState());
    await page.evaluate(() => document.getElementById('helpDialog').showModal()); await page.waitForFunction(() => !LoomApp.cpuInspector.active); assert.equal(await page.evaluate(() => LoomApp.engine.getDiagnostics().enabled), false, 'An open HTML dialog suspends profiling behind it.'); await page.evaluate(() => document.getElementById('helpDialog').close()); await summary.scrollIntoViewIfNeeded(); await page.waitForFunction(() => LoomApp.cpuInspector.active);
    await page.locator('[data-cpu-mode]').selectOption('deep'); await page.waitForFunction(() => LoomApp.engine.getDiagnostics().mode === 'deep' && LoomApp.engine.getDiagnostics().sampledBlocks > 0); await page.locator('[data-cpu-action="pause"]').click(); await page.waitForFunction(() => !LoomApp.engine.getDiagnostics().enabled); const paused = await page.evaluate(() => ({ interval: LoomApp.cpuInspector.interval, frame: LoomApp.cpuInspector.frame, longTasks: !!LoomApp.cpuInspector.longTaskObserver })); assert.deepEqual(paused, { interval: 0, frame: 0, longTasks: false }); await page.locator('[data-cpu-action="pause"]').click(); await page.waitForFunction(() => LoomApp.engine.getDiagnostics().enabled);
    await page.locator('[data-cpu-system-fold] > summary').click(); await page.locator('[data-cpu-monitor-ui]').check(); await page.waitForFunction(() => LoomApp.cpuInspector.frame !== 0); await page.evaluate(() => window.scrollTo(0, 0));
    await page.evaluate(() => { Object.defineProperty(document, 'hidden', { configurable: true, get: () => true }); document.dispatchEvent(new Event('visibilitychange')); }); await page.waitForFunction(() => !LoomApp.cpuInspector.active); assert.deepEqual(await page.evaluate(() => ({ enabled: LoomApp.engine.getDiagnostics().enabled, interval: LoomApp.cpuInspector.interval, frame: LoomApp.cpuInspector.frame, observer: !!LoomApp.cpuInspector.observer, longTask: !!LoomApp.cpuInspector.longTaskObserver })), { enabled: false, interval: 0, frame: 0, observer: false, longTask: false }); await page.evaluate(() => { delete document.hidden; document.dispatchEvent(new Event('visibilitychange')); }); await summary.scrollIntoViewIfNeeded(); await page.waitForFunction(() => LoomApp.cpuInspector.active);
    await page.evaluate(() => window.scrollTo(0, document.documentElement.scrollHeight)); await page.waitForFunction(() => !LoomApp.cpuInspector.active); assert.equal(await page.evaluate(() => LoomApp.engine.getDiagnostics().enabled), false); await summary.scrollIntoViewIfNeeded(); await page.waitForFunction(() => LoomApp.cpuInspector.active);
    await page.locator('[data-cpu-action="reset"]').click(); assert((await page.evaluate(() => LoomApp.cpuInspector.history.length)) <= 1); await page.waitForFunction(() => LoomApp.engine.getDiagnostics().sampledBlocks > 0);
    const download = page.waitForEvent('download'); await page.locator('[data-cpu-action="download"]').click(); const file = await download, bytes = fs.readFileSync(await file.path()), report = JSON.parse(bytes); assert.equal(report.format, 'galley-cpu-diagnostics'); assert(report.rows.some(row => row.effectType === 'preserve')); assert(!bytes.toString().includes('CPU_QA_PRIVATE_PROJECT'), 'Report excludes the project name.'); const privateKeys = new Set(['pcm', 'snapshot', 'inputDeviceId', 'outputDeviceId', 'clips', 'assets']); const inspect = value => { if (value && typeof value === 'object') for (const [key, nested] of Object.entries(value)) { assert(!privateKeys.has(key), 'Report excludes private data key ' + key); inspect(nested); } }; inspect(report); assert.deepEqual(await page.evaluate(() => LoomApp.getState()), stateBefore, 'Diagnostics controls never become project edits.');
    for (const width of [320, 390, 1440]) { await page.setViewportSize({ width, height: 1000 }); await summary.scrollIntoViewIfNeeded(); await page.locator('[data-cpu-owner="track-1"]').evaluate(element => element.open = true); const overflow = await hatch.evaluate(element => [...element.querySelectorAll('button,select,input,output')].filter(control => { const box = control.getBoundingClientRect(); return box.width && (box.left < -1 || box.right > innerWidth + 1); }).map(control => control.outerHTML.slice(0, 160))); assert.deepEqual(overflow, [], 'CPU controls fit ' + width + 'px'); assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1)); await hatch.screenshot({ path: path.join(artifacts, 'cpu-resources-' + width + '.png'), style: '.transport{position:static!important}#status{visibility:hidden!important}' }); }
    await summary.scrollIntoViewIfNeeded(); await summary.focus(); await summary.press('Enter'); await page.waitForFunction(() => !LoomApp.cpuInspector.active); const shut = await page.evaluate(() => ({ open: LoomApp.cpuInspector.element.open, interval: LoomApp.cpuInspector.interval, frame: LoomApp.cpuInspector.frame, observer: !!LoomApp.cpuInspector.observer, longTask: !!LoomApp.cpuInspector.longTaskObserver, enabled: LoomApp.engine.getDiagnostics().enabled })); assert.deepEqual(shut, { open: false, interval: 0, frame: 0, observer: false, longTask: false, enabled: false });
    assert.deepEqual(errors, []); assert.deepEqual(requests, []); evidence.ui = { closed, paused, shut, widths: [320, 390, 1440], owners: 13, reportBytes: bytes.length, built: Boolean(process.env.LOOM_CPU_QA_BUILT) };
  } finally { await page.evaluate(() => { LoomApp.cpuInspector.dispose(); return LoomApp.engine.dispose(); }).catch(() => {}); await context.close(); }
}
(async () => {
  fs.mkdirSync(artifacts, { recursive: true }); const server = await serve(), browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', headless: true, args: ['--no-sandbox', '--autoplay-policy=no-user-gesture-required'] });
  try { for (const phase of (process.env.LOOM_CPU_QA_PHASES || 'engine,ui').split(',')) { const start = Date.now(); if (phase === 'engine') await engineChecks(browser, server.url); else if (phase === 'ui') await uiChecks(browser, server.url); else throw Error('Unknown CPU phase ' + phase); passed.push({ phase, milliseconds: Date.now() - start }); fs.writeFileSync(path.join(artifacts, 'cpu-evidence.json'), JSON.stringify({ passed, evidence }, null, 2)); fs.writeFileSync(path.join(artifacts, 'cpu-' + phase + '-evidence.json'), JSON.stringify({ phase, evidence: evidence[phase] }, null, 2)); console.log('PASS CPU ' + phase); } console.log(JSON.stringify({ passed, artifacts })); }
  finally { await browser.close(); await server.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
